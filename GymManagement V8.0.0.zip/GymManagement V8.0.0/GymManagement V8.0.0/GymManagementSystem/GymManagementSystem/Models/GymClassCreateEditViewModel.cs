﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    public class GymClassCreateEditViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre de la clase es requerido")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        public string Name { get; set; }

        [Required(ErrorMessage = "La descripción es requerida")]
        [DataType(DataType.MultilineText)]
        public string Description { get; set; }

        [Required(ErrorMessage = "La fecha y hora son requeridas")]
        [Display(Name = "Fecha y Hora")]
        [DataType(DataType.DateTime)]
        public DateTime Schedule { get; set; }

        [Required(ErrorMessage = "La duración es requerida")]
        [Range(1, 240, ErrorMessage = "La duración debe ser entre 1-240 minutos")]
        [Display(Name = "Duración (minutos)")]
        public int DurationMinutes { get; set; }

        [Required(ErrorMessage = "El máximo de participantes es requerido")]
        [Range(1, 50, ErrorMessage = "El máximo de participantes debe ser 1-50")]
        [Display(Name = "Máximo Participantes")]
        public int MaxParticipants { get; set; }

        [Required(ErrorMessage = "Se requiere un instructor")]
        [Display(Name = "Instructor")]
        public string InstructorId { get; set; }

        public List<SelectListItem> Trainers { get; set; } = new List<SelectListItem>();
    }
}