﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// Representa a un entrenador dentro del sistema de gestión del gimnasio.
    /// Incluye información personal, de contacto, especialización, estado y relación con clases.
    /// </summary>
    public class Trainer
    {
        /// <summary>
        /// Identificador único del entrenador.
        /// Generado automáticamente por la base de datos.
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string Id { get; set; }

        /// <summary>
        /// Nombre del entrenador.
        /// </summary>
        [Required(ErrorMessage = "El nombre es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        /// <summary>
        /// Apellido del entrenador.
        /// </summary>
        [Required(ErrorMessage = "El apellido es obligatorio")]
        [StringLength(100, ErrorMessage = "El apellido no puede exceder 100 caracteres")]
        [Display(Name = "Apellido")]
        public string LastName { get; set; }

        /// <summary>
        /// Especialización del entrenador (ejemplo: Crossfit, Yoga, Pesas).
        /// </summary>
        [Required(ErrorMessage = "La especialización es requerida")]
        [StringLength(100, ErrorMessage = "La especialización no puede exceder 100 caracteres")]
        [Display(Name = "Especialización")]
        public string Specialization { get; set; }

        /// <summary>
        /// Correo electrónico del entrenador.
        /// </summary>
        [Required(ErrorMessage = "El email es obligatorio")]
        [EmailAddress(ErrorMessage = "Formato de email inválido")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        /// <summary>
        /// Teléfono de contacto del entrenador.
        /// </summary>
        [Required(ErrorMessage = "El teléfono es obligatorio")]
        [Phone(ErrorMessage = "Formato de teléfono inválido")]
        [Display(Name = "Teléfono")]
        public string Phone { get; set; }

        /// <summary>
        /// Fecha en la que fue contratado el entrenador.
        /// Por defecto se asigna la fecha actual.
        /// </summary>
        [Display(Name = "Fecha de Contratación")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime HireDate { get; set; } = DateTime.Now;

        /// <summary>
        /// Indica si el entrenador está activo en el gimnasio.
        /// </summary>
        [Display(Name = "Activo")]
        public bool IsActive { get; set; } = true;

        /// <summary>
        /// Breve biografía o descripción del entrenador.
        /// </summary>
        [Display(Name = "Biografía")]
        [StringLength(1000, ErrorMessage = "La biografía no puede exceder 1000 caracteres")]
        public string Bio { get; set; }

        /// <summary>
        /// Clases del gimnasio que imparte este entrenador.
        /// Relación uno a muchos con <see cref="GymClass"/>.
        /// </summary>
        public virtual ICollection<GymClass> GymClasses { get; set; } = new HashSet<GymClass>();

        /// <summary>
        /// Nombre completo calculado del entrenador (Nombre + Apellido).
        /// </summary>
        [NotMapped]
        [Display(Name = "Entrenador")]
        public string FullName => $"{Name} {LastName}";

        /// <summary>
        /// Verifica si el entrenador está disponible en una fecha y hora específica.
        /// Revisa si ya tiene una clase programada en ese horario.
        /// </summary>
        /// <param name="date">Fecha y hora a verificar.</param>
        /// <returns>True si está disponible, False si tiene una clase en ese horario.</returns>
        public bool IsAvailable(DateTime date)
        {
            return !GymClasses?.Any(gc =>
                gc.Schedule.Date == date.Date &&
                gc.Schedule <= date &&
                date <= gc.Schedule.AddMinutes(gc.DurationMinutes)) ?? true;
        }
    }
}
