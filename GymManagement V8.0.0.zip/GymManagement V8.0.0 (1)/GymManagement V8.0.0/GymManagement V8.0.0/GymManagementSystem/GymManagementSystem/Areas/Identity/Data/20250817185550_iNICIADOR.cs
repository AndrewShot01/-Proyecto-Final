﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GymManagementSystem.Areas.Identity.Data
{
    /// <summary>
    /// Migración: iNICIADOR
    /// Esta migración se creó como inicializador. 
    /// Actualmente no define cambios en la base de datos.
    /// </summary>
    public partial class iNICIADOR : Migration
    {
        /// <summary>
        /// Método Up:
        /// Aquí se definen las operaciones que se aplicarán a la base de datos
        /// cuando se ejecute la migración.
        /// En este caso está vacío porque aún no se agregaron cambios.
        /// </summary>
        /// <param name="migrationBuilder">Objeto utilizado para construir operaciones de migración</param>
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Aquí se colocarían las instrucciones para crear/alterar tablas, columnas, índices, etc.
        }

        /// <summary>
        /// Método Down:
        /// Aquí se definen las operaciones que revierten los cambios aplicados
        /// en el método Up, en caso de que se deshaga la migración.
        /// En este caso está vacío porque no hay cambios definidos en Up.
        /// </summary>
        /// <param name="migrationBuilder">Objeto utilizado para construir operaciones de migración</param>
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Aquí se colocarían las instrucciones para revertir los cambios realizados en Up.
        }
    }
}
