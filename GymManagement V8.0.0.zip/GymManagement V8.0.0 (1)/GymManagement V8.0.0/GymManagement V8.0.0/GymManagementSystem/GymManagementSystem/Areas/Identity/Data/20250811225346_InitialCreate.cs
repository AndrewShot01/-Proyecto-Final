﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GymManagementSystem.Areas.Identity.Data
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // ===============================
            // TABLA: AspNetRoles (Roles de usuarios)
            // ===============================
            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false), // Identificador único del rol
                    Name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true), // Nombre del rol
                    NormalizedName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true), // Nombre normalizado (en mayúsculas, sin acentos)
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true) // Control de concurrencia
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id); // Clave primaria
                });

            // ===============================
            // TABLA: AspNetUsers (Usuarios)
            // ===============================
            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false), // Identificador único
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false), // Nombre
                    LastName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false), // Apellido
                    RegistrationDate = table.Column<DateTime>(type: "datetime2", nullable: false), // Fecha de registro
                    MembershipExpiration = table.Column<DateTime>(type: "datetime2", nullable: true), // Vencimiento de membresía
                    MembershipType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false), // Tipo de membresía
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true), // Nombre de usuario
                    NormalizedUserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true), // Nombre de usuario normalizado
                    Email = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true), // Correo
                    NormalizedEmail = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true), // Correo normalizado
                    EmailConfirmed = table.Column<bool>(type: "bit", nullable: false), // Confirmación de correo
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: true), // Hash de la contraseña
                    SecurityStamp = table.Column<string>(type: "nvarchar(max)", nullable: true), // Token de seguridad
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true), // Control de concurrencia
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true), // Teléfono
                    PhoneNumberConfirmed = table.Column<bool>(type: "bit", nullable: false), // Confirmación de teléfono
                    TwoFactorEnabled = table.Column<bool>(type: "bit", nullable: false), // Autenticación de dos factores
                    LockoutEnd = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true), // Fin de bloqueo
                    LockoutEnabled = table.Column<bool>(type: "bit", nullable: false), // Habilitar bloqueo
                    AccessFailedCount = table.Column<int>(type: "int", nullable: false) // Intentos fallidos
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id); // Clave primaria
                });

            // ===============================
            // TABLA: Equipment (Equipos del gimnasio)
            // ===============================
            migrationBuilder.CreateTable(
                name: "Equipment",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"), // Identificador autoincremental
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false), // Nombre del equipo
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false), // Descripción
                    PurchaseDate = table.Column<DateTime>(type: "datetime2", nullable: false), // Fecha de compra
                    MaintenanceDate = table.Column<DateTime>(type: "datetime2", nullable: false), // Último mantenimiento
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false) // Estado del equipo
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Equipment", x => x.Id); // Clave primaria
                });

            // ===============================
            // TABLA: Trainers (Entrenadores)
            // ===============================
            migrationBuilder.CreateTable(
                name: "Trainers",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", maxLength: 450, nullable: false), // Identificador
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false), // Nombre
                    LastName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false), // Apellido
                    Specialization = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false), // Especialización
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false), // Correo
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: false), // Teléfono
                    HireDate = table.Column<DateTime>(type: "datetime2", nullable: false), // Fecha de contratación
                    IsActive = table.Column<bool>(type: "bit", nullable: false), // Estado activo/inactivo
                    Bio = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false) // Biografía
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Trainers", x => x.Id); // Clave primaria
                });

            // ===============================
            // Otras tablas relacionadas con Identity (Claims, Logins, Roles, Tokens)
            // ===============================
            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"), // Identificador
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false), // Id del rol
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true), // Tipo de claim
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true) // Valor del claim
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade); // Relación con Roles
                });

            // (Aquí se crean las tablas AspNetUserClaims, AspNetUserLogins, AspNetUserRoles, AspNetUserTokens con sus relaciones)
            // ...
            // ===============================
            // TABLA: GymClasses (Clases del gimnasio)
            // ===============================
            migrationBuilder.CreateTable(
                name: "GymClasses",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"), // Identificador
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false), // Nombre de la clase
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false), // Descripción
                    Schedule = table.Column<DateTime>(type: "datetime2", nullable: false), // Fecha y hora programada
                    DurationMinutes = table.Column<int>(type: "int", nullable: false), // Duración en minutos
                    MaxParticipants = table.Column<int>(type: "int", nullable: false), // Máx. participantes
                    InstructorId = table.Column<string>(type: "nvarchar(450)", nullable: false) // Relación con entrenador
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GymClasses", x => x.Id);
                    table.ForeignKey(
                        name: "FK_GymClasses_Trainers_InstructorId",
                        column: x => x.InstructorId,
                        principalTable: "Trainers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict); // Relación con entrenadores
                });

            // ===============================
            // TABLA: MemberClasses (Relación miembros con clases)
            // ===============================
            migrationBuilder.CreateTable(
                name: "MemberClasses",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"), // Identificador
                    MemberId = table.Column<string>(type: "nvarchar(450)", nullable: false), // Id del miembro
                    GymClassId = table.Column<int>(type: "int", nullable: false), // Id de la clase
                    BookingDate = table.Column<DateTime>(type: "datetime2", nullable: false), // Fecha de reserva
                    Attended = table.Column<bool>(type: "bit", nullable: false), // Si asistió o no
                    Rating = table.Column<int>(type: "int", nullable: true), // Calificación dada
                    Feedback = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false), // Comentarios
                    IsCancelled = table.Column<bool>(type: "bit", nullable: false), // Si se canceló
                    CancellationDate = table.Column<DateTime>(type: "datetime2", nullable: true) // Fecha de cancelación
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MemberClasses", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MemberClasses_AspNetUsers_MemberId",
                        column: x => x.MemberId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade); // Relación con usuarios
                    table.ForeignKey(
                        name: "FK_MemberClasses_GymClasses_GymClassId",
                        column: x => x.GymClassId,
                        principalTable: "GymClasses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade); // Relación con clases
                });

            // ===============================
            // Creación de índices para mejorar consultas
            // ===============================
            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true,
                filter: "[NormalizedName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true,
                filter: "[NormalizedUserName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_GymClasses_InstructorId",
                table: "GymClasses",
                column: "InstructorId");

            migrationBuilder.CreateIndex(
                name: "IX_MemberClasses_GymClassId",
                table: "MemberClasses",
                column: "GymClassId");

            migrationBuilder.CreateIndex(
                name: "IX_MemberClasses_MemberId",
                table: "MemberClasses",
                column: "MemberId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Elimina todas las tablas en orden inverso para evitar errores de dependencias
            migrationBuilder.DropTable(name: "AspNetRoleClaims");
            migrationBuilder.DropTable(name: "AspNetUserClaims");
            migrationBuilder.DropTable(name: "AspNetUserLogins");
            migrationBuilder.DropTable(name: "AspNetUserRoles");
            migrationBuilder.DropTable(name: "AspNetUserTokens");
            migrationBuilder.DropTable(name: "Equipment");
            migrationBuilder.DropTable(name: "MemberClasses");
            migrationBuilder.DropTable(name: "AspNetRoles");
            migrationBuilder.DropTable(name: "AspNetUsers");
            migrationBuilder.DropTable(name: "GymClasses");
            migrationBuilder.DropTable(name: "Trainers");
        }
    }
}
