using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GymManagementSystem.Views.GymClasses
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
