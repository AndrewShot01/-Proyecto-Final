﻿using GymManagementSystem.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace GymManagementSystem.Areas.Identity.Data
{
    public class ApplicationDbContext : IdentityDbContext<Member>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<GymClass> GymClasses { get; set; }
        public DbSet<Trainer> Trainers { get; set; }
        public DbSet<Equipment> Equipment { get; set; }
        public DbSet<MemberClass> MemberClasses { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Configuración de Member
            builder.Entity<Member>(entity =>
            {
                entity.Property(m => m.Name).IsRequired().HasMaxLength(100);
                entity.Property(m => m.LastName).IsRequired().HasMaxLength(100);
                entity.Property(m => m.MembershipType).HasMaxLength(50);
            });

            // Configuración de Trainer
            builder.Entity<Trainer>(entity =>
            {
                entity.Property(t => t.Id).HasMaxLength(450);
                entity.Property(t => t.Name).IsRequired().HasMaxLength(100);
                entity.Property(t => t.LastName).IsRequired().HasMaxLength(100);
                entity.Property(t => t.Specialization).HasMaxLength(200);
                entity.Property(t => t.Email).IsRequired();
                entity.Property(t => t.Phone).IsRequired();
            });

            // Configuración de GymClass
            builder.Entity<GymClass>(entity =>
            {
                entity.Property(g => g.Name).IsRequired().HasMaxLength(100);
                entity.Property(g => g.Description).IsRequired();
                entity.Property(g => g.InstructorId).IsRequired();
            });

            // Configuración de MemberClass
            builder.Entity<MemberClass>(entity =>
            {
                entity.Property(mc => mc.MemberId).IsRequired();
                entity.Property(mc => mc.GymClassId).IsRequired();
                entity.Property(mc => mc.Feedback).HasMaxLength(500);
            });

            // Configuración de relaciones
            builder.Entity<MemberClass>()
                .HasOne(mc => mc.Member)
                .WithMany(m => m.MemberClasses)
                .HasForeignKey(mc => mc.MemberId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<MemberClass>()
                .HasOne(mc => mc.GymClass)
                .WithMany(gc => gc.MemberClasses)
                .HasForeignKey(mc => mc.GymClassId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<GymClass>()
                .HasOne(g => g.Instructor)
                .WithMany(t => t.GymClasses)
                .HasForeignKey(g => g.InstructorId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configuración para Equipment si es necesario
            builder.Entity<Equipment>(entity =>
            {
                entity.Property(e => e.Name).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Description).HasMaxLength(500);
            });
        }
    }
}