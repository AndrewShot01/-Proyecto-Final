﻿using GymManagementSystem.Areas.Identity.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// ViewModel que representa el detalle completo de una clase de gimnasio,
    /// incluyendo información general, estadísticas y lista de asistentes.
    /// </summary>
    public class GymClassDetailViewModel
    {
        /// <summary>
        /// Identificador único de la clase.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Nombre de la clase.
        /// </summary>
        [Display(Name = "Nombre de Clase")]
        public string Name { get; set; }

        /// <summary>
        /// Descripción de la clase.
        /// </summary>
        [Display(Name = "Descripción")]
        public string Description { get; set; }

        /// <summary>
        /// Fecha y hora de inicio de la clase.
        /// </summary>
        [Display(Name = "Fecha y Hora")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm}")]
        public DateTime Schedule { get; set; }

        /// <summary>
        /// Hora de finalización de la clase.
        /// </summary>
        [Display(Name = "Hora de Finalización")]
        [DisplayFormat(DataFormatString = "{0:HH:mm}")]
        public DateTime EndTime { get; set; }

        /// <summary>
        /// Duración en minutos de la clase.
        /// </summary>
        [Display(Name = "Duración (minutos)")]
        public int DurationMinutes { get; set; }

        /// <summary>
        /// Número máximo de participantes permitidos.
        /// </summary>
        [Display(Name = "Máximo de Participantes")]
        public int MaxParticipants { get; set; }

        /// <summary>
        /// Cantidad de cupos disponibles en la clase.
        /// </summary>
        [Display(Name = "Cupos Disponibles")]
        public int AvailableSpots { get; set; }

        /// <summary>
        /// Estado de la clase (ej: Disponible, Llena, Finalizada).
        /// </summary>
        [Display(Name = "Estado")]
        public string Status { get; set; }

        /// <summary>
        /// Nombre del instructor asignado a la clase.
        /// </summary>
        [Display(Name = "Instructor")]
        public string InstructorName { get; set; }

        /// <summary>
        /// Identificador del instructor asignado.
        /// </summary>
        [Display(Name = "ID del Instructor")]
        public string InstructorId { get; set; }

        /// <summary>
        /// Lista de asistentes inscritos en la clase.
        /// </summary>
        public List<AttendeeViewModel> Attendees { get; set; } = new List<AttendeeViewModel>();

        // ================== ESTADÍSTICAS ==================

        /// <summary>
        /// Cantidad total de inscritos.
        /// </summary>
        [Display(Name = "Total Inscritos")]
        public int TotalAttendees => Attendees.Count;

        /// <summary>
        /// Cantidad de asistentes que confirmaron su asistencia.
        /// </summary>
        [Display(Name = "Asistencia Confirmada")]
        public int ConfirmedAttendance => Attendees.Count(a => a.Attended);

        /// <summary>
        /// Porcentaje de asistencia en relación al total de inscritos.
        /// </summary>
        [Display(Name = "Porcentaje de Asistencia")]
        [DisplayFormat(DataFormatString = "{0:P0}")]
        public double AttendancePercentage => TotalAttendees > 0 ? (double)ConfirmedAttendance / TotalAttendees : 0;

        // ================== ACCIONES PERMITIDAS ==================

        /// <summary>
        /// Indica si la clase puede ser editada.
        /// </summary>
        public bool CanEdit { get; set; }

        /// <summary>
        /// Indica si la clase puede ser cancelada.
        /// </summary>
        public bool CanCancel { get; set; }

        /// <summary>
        /// Indica si se puede registrar asistencia a la clase.
        /// </summary>
        public bool CanMarkAttendance { get; set; }
    }
}
