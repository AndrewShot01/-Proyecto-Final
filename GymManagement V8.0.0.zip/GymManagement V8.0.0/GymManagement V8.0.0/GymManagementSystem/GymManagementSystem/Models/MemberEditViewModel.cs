﻿using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    public class MemberEditViewModel
    {
        public string Id { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        [Required(ErrorMessage = "El apellido es obligatorio")]
        [Display(Name = "Apellido")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "El email es obligatorio")]
        [EmailAddress(ErrorMessage = "Formato de email inválido")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "El teléfono es obligatorio")]
        [Phone(ErrorMessage = "Formato de teléfono inválido")]
        [Display(Name = "Teléfono")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "El tipo de membresía es obligatorio")]
        [Display(Name = "Tipo de Membresía")]
        public string MembershipType { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Fecha de Expiración")]
        public DateTime? MembershipExpiration { get; set; }
    }
}
