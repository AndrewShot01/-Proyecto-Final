﻿using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// ViewModel usado para la creación y edición de entrenadores en el sistema.
    /// Contiene validaciones y atributos necesarios para el formulario.
    /// </summary>
    public class TrainerCreateEditViewModel
    {
        /// <summary>
        /// Identificador único del entrenador.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Nombre del entrenador.
        /// </summary>
        [Required(ErrorMessage = "El nombre es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        /// <summary>
        /// Apellido del entrenador.
        /// </summary>
        [Required(ErrorMessage = "El apellido es obligatorio")]
        [StringLength(100, ErrorMessage = "El apellido no puede exceder 100 caracteres")]
        [Display(Name = "Apellido")]
        public string LastName { get; set; }

        /// <summary>
        /// Especialización del entrenador (ejemplo: Yoga, Crossfit, Pesas).
        /// </summary>
        [Required(ErrorMessage = "La especialización es requerida")]
        [StringLength(100, ErrorMessage = "La especialización no puede exceder 100 caracteres")]
        [Display(Name = "Especialización")]
        public string Specialization { get; set; }

        /// <summary>
        /// Correo electrónico de contacto del entrenador.
        /// </summary>
        [Required(ErrorMessage = "El email es obligatorio")]
        [EmailAddress(ErrorMessage = "Formato de email inválido")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        /// <summary>
        /// Número de teléfono del entrenador.
        /// </summary>
        [Required(ErrorMessage = "El teléfono es obligatorio")]
        [Phone(ErrorMessage = "Formato de teléfono inválido")]
        [Display(Name = "Teléfono")]
        public string Phone { get; set; }

        /// <summary>
        /// Breve biografía o descripción del entrenador.
        /// </summary>
        [Display(Name = "Biografía")]
        [StringLength(1000, ErrorMessage = "La biografía no puede exceder 1000 caracteres")]
        public string Bio { get; set; }
    }
}
