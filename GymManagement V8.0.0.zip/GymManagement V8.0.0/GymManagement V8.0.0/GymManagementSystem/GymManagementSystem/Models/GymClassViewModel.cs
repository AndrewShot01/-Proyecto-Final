﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    public class GymClassViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre de la clase es requerido")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        [Display(Name = "Nombre de Clase")]
        public string Name { get; set; }

        [Required(ErrorMessage = "La descripción es requerida")]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Descripción")]
        public string Description { get; set; }

        [Required(ErrorMessage = "La fecha y hora son requeridas")]
        [Display(Name = "Fecha y Hora")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-ddTHH:mm}", ApplyFormatInEditMode = true)]
        public DateTime Schedule { get; set; }

        [Display(Name = "Hora de Finalización")]
        public DateTime EndTime => Schedule.AddMinutes(DurationMinutes);

        [Required(ErrorMessage = "La duración es requerida")]
        [Range(1, 240, ErrorMessage = "La duración debe ser entre 1-240 minutos")]
        [Display(Name = "Duración (minutos)")]
        public int DurationMinutes { get; set; }

        [Required(ErrorMessage = "El máximo de participantes es requerido")]
        [Range(1, 50, ErrorMessage = "El máximo de participantes debe ser 1-50")]
        [Display(Name = "Máximo de Participantes")]
        public int MaxParticipants { get; set; }

        [Display(Name = "Disponibilidad")]
        public int AvailableSpots { get; set; }

        [Display(Name = "Estado")]
        public string Status { get; set; }

        [Required(ErrorMessage = "Se requiere un instructor")]
        [Display(Name = "Instructor")]
        public string InstructorId { get; set; }  // ID para binding con formularios

        [Display(Name = "Nombre del Instructor")]
        public string InstructorName { get; set; } // Solo para visualización



       public static string GetStatus(DateTime schedule, int duration, int maxParticipants, int currentParticipants)
        {
            var now = DateTime.Now;
            var endTime = schedule.AddMinutes(duration);

            if (now > endTime) return "Finalizada";
            if (now >= schedule && now <= endTime) return "En curso";
            if (currentParticipants >= maxParticipants) return "Llena";
            return "Disponible";
        }

    }
}