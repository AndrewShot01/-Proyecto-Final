﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// ViewModel que representa la información de un asistente (miembro) a una clase de gimnasio.
    /// Contiene datos de identificación, contacto, estado de la inscripción y propiedades auxiliares para la interfaz de usuario.
    /// </summary>
    public class AttendeeViewModel
    {
        /// <summary>
        /// Identificador único del miembro.
        /// </summary>
        [Display(Name = "ID Miembro")]
        public string MemberId { get; set; }

        /// <summary>
        /// Nombre completo del miembro.
        /// </summary>
        [Required]
        [Display(Name = "Nombre Completo")]
        public string FullName { get; set; }

        /// <summary>
        /// Fecha en la que el miembro se inscribió a la clase.
        /// </summary>
        [Display(Name = "Fecha Inscripción")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm}")]
        public DateTime EnrollmentDate { get; set; }

        /// <summary>
        /// Indica si el miembro asistió a la clase.
        /// </summary>
        [Display(Name = "Asistencia")]
        public bool Attended { get; set; }

        /// <summary>
        /// Número de teléfono del miembro.
        /// </summary>
        [Display(Name = "Teléfono")]
        [Phone(ErrorMessage = "Formato de teléfono inválido")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Correo electrónico del miembro.
        /// </summary>
        [Display(Name = "Email")]
        [EmailAddress(ErrorMessage = "Formato de email inválido")]
        public string Email { get; set; }

        /// <summary>
        /// Tipo de membresía del miembro (ej: Básica, Premium).
        /// </summary>
        [Display(Name = "Tipo Membresía")]
        public string MembershipType { get; set; }

        /// <summary>
        /// Indica si la inscripción del miembro está activa (no cancelada ni expirada).
        /// </summary>
        [Display(Name = "Inscripción Activa")]
        public bool IsActive => !IsCancelled && !HasExpired;

        /// <summary>
        /// Indica si la inscripción fue cancelada.
        /// </summary>
        [Display(Name = "Cancelada")]
        public bool IsCancelled { get; set; }

        /// <summary>
        /// Indica si la inscripción expiró.
        /// </summary>
        [Display(Name = "Expirada")]
        public bool HasExpired { get; set; }

        /// <summary>
        /// Comentarios o retroalimentación del miembro respecto a la clase.
        /// </summary>
        [Display(Name = "Comentarios")]
        [StringLength(500, ErrorMessage = "Máximo 500 caracteres")]
        public string Feedback { get; set; }

        /// <summary>
        /// Estado calculado de la inscripción (Cancelada, Expirada, Asistió o Inscrito).
        /// </summary>
        [Display(Name = "Estado")]
        public string Status
        {
            get
            {
                if (IsCancelled) return "Cancelada";
                if (HasExpired) return "Expirada";
                if (Attended) return "Asistió";
                return "Inscrito";
            }
        }

        /// <summary>
        /// Nombre de la clase a la que pertenece la inscripción.
        /// </summary>
        [Display(Name = "Clase")]
        public string ClassName { get; set; }

        /// <summary>
        /// Identificador de la clase a la que pertenece la inscripción.
        /// </summary>
        [Display(Name = "ID Clase")]
        public int ClassId { get; set; }

        /// <summary>
        /// Nombre del miembro (puede ser redundante con FullName pero útil en algunos contextos de UI).
        /// </summary>
        public string MemberName { get; internal set; }

        /// <summary>
        /// Fecha en que el miembro reservó la clase.
        /// </summary>
        public DateTime BookingDate { get; internal set; }
    }
}
