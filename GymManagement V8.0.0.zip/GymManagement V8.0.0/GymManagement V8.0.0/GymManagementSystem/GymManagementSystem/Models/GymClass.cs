﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GymManagementSystem.Models
{
    public class GymClass
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre de la clase es requerido")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        [Display(Name = "Nombre de Clase")]
        public string Name { get; set; }

        [Required(ErrorMessage = "La descripción es requerida")]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Descripción")]
        public string Description { get; set; }

        [Required(ErrorMessage = "La fecha y hora son requeridas")]
        [Display(Name = "Fecha y Hora")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-ddTHH:mm}", ApplyFormatInEditMode = true)]
        public DateTime Schedule { get; set; }

        [Required(ErrorMessage = "La duración es requerida")]
        [Range(1, 100, ErrorMessage = "La duración debe ser entre 1-100 minutos")]
        [Display(Name = "Duración (minutos)")]
        public int DurationMinutes { get; set; }

        [Required(ErrorMessage = "El máximo de participantes es requerido")]
        [Range(1, 50, ErrorMessage = "El máximo de participantes debe ser 1-50")]
        [Display(Name = "Máximo de Participantes")]
        public int MaxParticipants { get; set; }

        [Required(ErrorMessage = "Se requiere un instructor")]
        [Display(Name = "Instructor")]
        public string InstructorId { get; set; }  // Mantenemos string para coincidir con Trainer.Id

        // Relación con Trainer
        [ForeignKey("InstructorId")]
        public virtual Trainer Instructor { get; set; }

        // Relación con MemberClass
        public virtual ICollection<MemberClass> MemberClasses { get; set; } = new HashSet<MemberClass>();

        // Propiedades calculadas
        [NotMapped]
        [Display(Name = "Hora de Finalización")]
        public DateTime EndTime => Schedule.AddMinutes(DurationMinutes);

        [NotMapped]
        [Display(Name = "Disponibilidad")]
        public int AvailableSpots => MaxParticipants - (MemberClasses?.Count ?? 0);

        [NotMapped]
        [Display(Name = "Estado")]
        public string Status
        {
            get
            {
                if (Schedule < DateTime.Now) return "Finalizada";
                return AvailableSpots > 0 ? "Disponible" : "Llena";
            }
        }
    }
}
