using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GymManagementSystem.Views.Account
{
    public class ProfileModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
