﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// ViewModel usado para la creación y edición de clases de gimnasio.
    /// Contiene validaciones y la lista de entrenadores disponibles.
    /// </summary>
    public class GymClassCreateEditViewModel
    {
        /// <summary>
        /// Identificador único de la clase (usado en edición).
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Nombre de la clase.
        /// </summary>
        [Required(ErrorMessage = "El nombre de la clase es requerido")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        public string Name { get; set; }

        /// <summary>
        /// Descripción de la clase.
        /// </summary>
        [Required(ErrorMessage = "La descripción es requerida")]
        [DataType(DataType.MultilineText)]
        public string Description { get; set; }

        /// <summary>
        /// Fecha y hora programada de la clase.
        /// </summary>
        [Required(ErrorMessage = "La fecha y hora son requeridas")]
        [Display(Name = "Fecha y Hora")]
        [DataType(DataType.DateTime)]
        public DateTime Schedule { get; set; }

        /// <summary>
        /// Duración en minutos de la clase.
        /// </summary>
        [Required(ErrorMessage = "La duración es requerida")]
        [Range(1, 240, ErrorMessage = "La duración debe ser entre 1-240 minutos")]
        [Display(Name = "Duración (minutos)")]
        public int DurationMinutes { get; set; }

        /// <summary>
        /// Número máximo de participantes permitidos.
        /// </summary>
        [Required(ErrorMessage = "El máximo de participantes es requerido")]
        [Range(1, 50, ErrorMessage = "El máximo de participantes debe ser 1-50")]
        [Display(Name = "Máximo Participantes")]
        public int MaxParticipants { get; set; }

        /// <summary>
        /// Identificador del instructor asignado (relacionado con Trainer).
        /// </summary>
        [Required(ErrorMessage = "Se requiere un instructor")]
        [Display(Name = "Instructor")]
        public string InstructorId { get; set; }

        /// <summary>
        /// Lista de entrenadores disponibles para asignar a la clase (usada en dropdown en la vista).
        /// </summary>
        public List<SelectListItem> Trainers { get; set; } = new List<SelectListItem>();
    }
}
