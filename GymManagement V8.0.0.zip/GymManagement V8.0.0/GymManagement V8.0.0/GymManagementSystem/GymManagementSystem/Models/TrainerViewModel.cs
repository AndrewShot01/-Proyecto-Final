﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    public class TrainerViewModel
    {
        public string Id { get; set; }

        [Display(Name = "Nombre Completo")]
        public string FullName { get; set; }

        [Display(Name = "Especialización")]
        public string Specialization { get; set; }

        [Display(Name = "Email")]
        [EmailAddress]
        public string Email { get; set; }

        [Display(Name = "Teléfono")]
        [Phone]
        public string Phone { get; set; }

        [Display(Name = "Fecha Contratación")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime HireDate { get; set; }

        [Display(Name = "Clases Activas")]
        public int ActiveClassesCount { get; set; }

        [Display(Name = "Estado")]
        public string Status => IsActive ? "Activo" : "Inactivo";

        [Display(Name = "Activo")]
        public bool IsActive { get; set; }
    }
}