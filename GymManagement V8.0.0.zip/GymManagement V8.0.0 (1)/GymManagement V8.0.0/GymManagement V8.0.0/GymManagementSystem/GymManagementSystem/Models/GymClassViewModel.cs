﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// ViewModel que representa la información de una clase de gimnasio,
    /// utilizado para mostrar y validar datos en la UI.
    /// </summary>
    public class GymClassViewModel
    {
        /// <summary>
        /// Identificador único de la clase.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Nombre de la clase.
        /// </summary>
        [Required(ErrorMessage = "El nombre de la clase es requerido")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        [Display(Name = "Nombre de Clase")]
        public string Name { get; set; }

        /// <summary>
        /// Descripción detallada de la clase.
        /// </summary>
        [Required(ErrorMessage = "La descripción es requerida")]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Descripción")]
        public string Description { get; set; }

        /// <summary>
        /// Fecha y hora en que inicia la clase.
        /// </summary>
        [Required(ErrorMessage = "La fecha y hora son requeridas")]
        [Display(Name = "Fecha y Hora")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-ddTHH:mm}", ApplyFormatInEditMode = true)]
        public DateTime Schedule { get; set; }

        /// <summary>
        /// Hora de finalización calculada automáticamente
        /// en base a la duración de la clase.
        /// </summary>
        [Display(Name = "Hora de Finalización")]
        public DateTime EndTime => Schedule.AddMinutes(DurationMinutes);

        /// <summary>
        /// Duración en minutos de la clase.
        /// </summary>
        [Required(ErrorMessage = "La duración es requerida")]
        [Range(1, 240, ErrorMessage = "La duración debe ser entre 1-240 minutos")]
        [Display(Name = "Duración (minutos)")]
        public int DurationMinutes { get; set; }

        /// <summary>
        /// Número máximo de participantes permitidos en la clase.
        /// </summary>
        [Required(ErrorMessage = "El máximo de participantes es requerido")]
        [Range(1, 50, ErrorMessage = "El máximo de participantes debe ser 1-50")]
        [Display(Name = "Máximo de Participantes")]
        public int MaxParticipants { get; set; }

        /// <summary>
        /// Cupos disponibles en la clase (calculados externamente).
        /// </summary>
        [Display(Name = "Disponibilidad")]
        public int AvailableSpots { get; set; }

        /// <summary>
        /// Estado actual de la clase (Disponible, Llena, En curso, Finalizada).
        /// </summary>
        [Display(Name = "Estado")]
        public string Status { get; set; }

        /// <summary>
        /// Identificador del instructor asignado.
        /// Usado para binding con formularios.
        /// </summary>
        [Required(ErrorMessage = "Se requiere un instructor")]
        [Display(Name = "Instructor")]
        public string InstructorId { get; set; }

        /// <summary>
        /// Nombre del instructor (solo para mostrar en UI).
        /// </summary>
        [Display(Name = "Nombre del Instructor")]
        public string InstructorName { get; set; }

        /// <summary>
        /// Método estático que calcula el estado de la clase 
        /// según la fecha, duración y ocupación.
        /// </summary>
        /// <param name="schedule">Fecha y hora de inicio.</param>
        /// <param name="duration">Duración en minutos.</param>
        /// <param name="maxParticipants">Capacidad máxima.</param>
        /// <param name="currentParticipants">Número actual de participantes inscritos.</param>
        /// <returns>Estado de la clase (Disponible, Llena, En curso, Finalizada).</returns>
        public static string GetStatus(DateTime schedule, int duration, int maxParticipants, int currentParticipants)
        {
            var now = DateTime.Now;
            var endTime = schedule.AddMinutes(duration);

            if (now > endTime) return "Finalizada";
            if (now >= schedule && now <= endTime) return "En curso";
            if (currentParticipants >= maxParticipants) return "Llena";
            return "Disponible";
        }
    }
}
