﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// ViewModel utilizado para mostrar información de un entrenador
    /// en vistas de detalle, listado o reportes.
    /// </summary>
    public class TrainerViewModel
    {
        /// <summary>
        /// Identificador único del entrenador.
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Nombre completo del entrenador (Nombre + Apellido).
        /// </summary>
        [Display(Name = "Nombre Completo")]
        public string FullName { get; set; }

        /// <summary>
        /// Especialización del entrenador (ejemplo: Yoga, Crossfit, Spinning).
        /// </summary>
        [Display(Name = "Especialización")]
        public string Specialization { get; set; }

        /// <summary>
        /// Correo electrónico de contacto del entrenador.
        /// </summary>
        [Display(Name = "Email")]
        [EmailAddress]
        public string Email { get; set; }

        /// <summary>
        /// Número de teléfono de contacto del entrenador.
        /// </summary>
        [Display(Name = "Teléfono")]
        [Phone]
        public string Phone { get; set; }

        /// <summary>
        /// Fecha en que el entrenador fue contratado.
        /// </summary>
        [Display(Name = "Fecha Contratación")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime HireDate { get; set; }

        /// <summary>
        /// Cantidad de clases activas asignadas al entrenador.
        /// </summary>
        [Display(Name = "Clases Activas")]
        public int ActiveClassesCount { get; set; }

        /// <summary>
        /// Estado legible del entrenador ("Activo" o "Inactivo").
        /// </summary>
        [Display(Name = "Estado")]
        public string Status => IsActive ? "Activo" : "Inactivo";

        /// <summary>
        /// Indica si el entrenador se encuentra activo en el sistema.
        /// </summary>
        [Display(Name = "Activo")]
        public bool IsActive { get; set; }
    }
}
