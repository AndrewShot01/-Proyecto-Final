﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GymManagementSystem.Models
{
    public class Trainer
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string Id { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        [Required(ErrorMessage = "El apellido es obligatorio")]
        [StringLength(100, ErrorMessage = "El apellido no puede exceder 100 caracteres")]
        [Display(Name = "Apellido")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "La especialización es requerida")]
        [StringLength(100, ErrorMessage = "La especialización no puede exceder 100 caracteres")]
        [Display(Name = "Especialización")]
        public string Specialization { get; set; }

        [Required(ErrorMessage = "El email es obligatorio")]
        [EmailAddress(ErrorMessage = "Formato de email inválido")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "El teléfono es obligatorio")]
        [Phone(ErrorMessage = "Formato de teléfono inválido")]
        [Display(Name = "Teléfono")]
        public string Phone { get; set; }

        [Display(Name = "Fecha de Contratación")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime HireDate { get; set; } = DateTime.Now;

        [Display(Name = "Activo")]
        public bool IsActive { get; set; } = true;

        [Display(Name = "Biografía")]
        [StringLength(1000, ErrorMessage = "La biografía no puede exceder 1000 caracteres")]
        public string Bio { get; set; }

        // Relación con GymClass
        public virtual ICollection<GymClass> GymClasses { get; set; } = new HashSet<GymClass>();

        // Propiedad calculada
        [NotMapped]
        [Display(Name = "Entrenador")]
        public string FullName => $"{Name} {LastName}";

        // Método para verificar disponibilidad
        public bool IsAvailable(DateTime date)
        {
            return !GymClasses?.Any(gc =>
                gc.Schedule.Date == date.Date &&
                gc.Schedule <= date &&
                date <= gc.Schedule.AddMinutes(gc.DurationMinutes)) ?? true;
        }
    }
}