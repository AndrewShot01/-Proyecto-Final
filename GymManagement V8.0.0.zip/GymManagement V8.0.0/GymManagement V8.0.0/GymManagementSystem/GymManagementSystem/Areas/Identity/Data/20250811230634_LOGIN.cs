﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GymManagementSystem.Areas.Identity.Data
{
    /// <inheritdoc />
    public partial class LOGIN : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
        name: "MembershipType",
        table: "AspNetUsers",
        nullable: false,
        defaultValue: "Basic",
        oldClrType: typeof(string));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
