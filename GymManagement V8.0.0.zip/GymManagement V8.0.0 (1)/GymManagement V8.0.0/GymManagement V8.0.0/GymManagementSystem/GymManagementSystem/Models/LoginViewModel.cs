﻿using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// ViewModel utilizado para manejar la información
    /// del formulario de inicio de sesión (login).
    /// </summary>
    public class LoginViewModel
    {
        /// <summary>
        /// Correo electrónico del usuario.
        /// Campo obligatorio con validación de formato de email.
        /// </summary>
        [Required(ErrorMessage = "El email es obligatorio")]
        [EmailAddress(ErrorMessage = "Formato de email inválido")]
        public string Email { get; set; }

        /// <summary>
        /// Contraseña del usuario.
        /// Campo obligatorio con tipo de dato protegido (Password).
        /// </summary>
        [Required(ErrorMessage = "La contraseña es obligatoria")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        /// <summary>
        /// Indica si el usuario desea que su sesión
        /// se recuerde en el dispositivo.
        /// </summary>
        [Display(Name = "¿Recordarme?")]
        public bool RememberMe { get; set; }

        /// <summary>
        /// URL de retorno después de un inicio de sesión exitoso.
        /// Puede ser nula si no se especifica.
        /// </summary>
        public string? ReturnUrl { get; set; }
    }
}
