﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// ViewModel para editar la información de un miembro del gimnasio.
    /// </summary>
    public class MemberEditViewModel
    {
        /// <summary>
        /// Identificador único del miembro (IdentityUser.Id).
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Nombre del miembro.
        /// </summary>
        [Required(ErrorMessage = "El nombre es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder los 100 caracteres")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        /// <summary>
        /// Apellido del miembro.
        /// </summary>
        [Required(ErrorMessage = "El apellido es obligatorio")]
        [StringLength(100, ErrorMessage = "El apellido no puede exceder los 100 caracteres")]
        [Display(Name = "Apellido")]
        public string LastName { get; set; }

        /// <summary>
        /// Correo electrónico del miembro.
        /// </summary>
        [Required(ErrorMessage = "El email es obligatorio")]
        [EmailAddress(ErrorMessage = "Formato de email inválido")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        /// <summary>
        /// Número de teléfono del miembro.
        /// </summary>
        [Required(ErrorMessage = "El teléfono es obligatorio")]
        [Phone(ErrorMessage = "Formato de teléfono inválido")]
        [Display(Name = "Teléfono")]
        public string Phone { get; set; }

        /// <summary>
        /// Tipo de membresía actual del miembro (ej. Basic, Premium, VIP).
        /// </summary>
        [Required(ErrorMessage = "El tipo de membresía es obligatorio")]
        [Display(Name = "Tipo de Membresía")]
        public string MembershipType { get; set; }

        /// <summary>
        /// Fecha de expiración de la membresía (nullable).
        /// </summary>
        [DataType(DataType.Date)]
        [Display(Name = "Fecha de Expiración")]
        public DateTime? MembershipExpiration { get; set; }
    }
}
