using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GymManagementSystem.Views.Trainers
{
    public class _TrainerFormFieldsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
