﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    public class AttendeeViewModel
    {
        [Display(Name = "ID Miembro")]
        public string MemberId { get; set; }

        [Required]
        [Display(Name = "Nombre Completo")]
        public string FullName { get; set; }

        [Display(Name = "Fecha Inscripción")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm}")]
        public DateTime EnrollmentDate { get; set; }

        [Display(Name = "Asistencia")]
        public bool Attended { get; set; }

        [Display(Name = "Teléfono")]
        [Phone(ErrorMessage = "Formato de teléfono inválido")]
        public string PhoneNumber { get; set; }

        [Display(Name = "Email")]
        [EmailAddress(ErrorMessage = "Formato de email inválido")]
        public string Email { get; set; }

        [Display(Name = "Tipo Membresía")]
        public string MembershipType { get; set; }

        [Display(Name = "Inscripción Activa")]
        public bool IsActive => !IsCancelled && !HasExpired;

        [Display(Name = "Cancelada")]
        public bool IsCancelled { get; set; }

        [Display(Name = "Expirada")]
        public bool HasExpired { get; set; }

        [Display(Name = "Comentarios")]
        [StringLength(500, ErrorMessage = "Máximo 500 caracteres")]
        public string Feedback { get; set; }

        // Propiedades para UI
        [Display(Name = "Estado")]
        public string Status
        {
            get
            {
                if (IsCancelled) return "Cancelada";
                if (HasExpired) return "Expirada";
                if (Attended) return "Asistió";
                return "Inscrito";
            }
        }

        [Display(Name = "Clase")]
        public string ClassName { get; set; }

        [Display(Name = "ID Clase")]
        public int ClassId { get; set; }
        public string MemberName { get; internal set; }
        public DateTime BookingDate { get; internal set; }
    }
}

