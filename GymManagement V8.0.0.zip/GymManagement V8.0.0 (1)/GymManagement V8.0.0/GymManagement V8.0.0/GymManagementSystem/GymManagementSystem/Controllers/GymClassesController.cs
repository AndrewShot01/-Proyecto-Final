﻿using GymManagementSystem.Areas.Identity.Data;     // Acceso al ApplicationDbContext y al tipo Member (Identity)
using GymManagementSystem.Models;                  // Modelos y ViewModels usados por el controlador
using Microsoft.AspNetCore.Authorization;          // Atributos de autorización [Authorize]
using Microsoft.AspNetCore.Identity;               // UserManager y SignInManager para Identity
using Microsoft.AspNetCore.Mvc;                    // Tipos base de MVC
using Microsoft.AspNetCore.Mvc.Rendering;          // SelectListItem para combos en vistas
using Microsoft.EntityFrameworkCore;               // Extensiones EF Core (Include, ThenInclude, etc.)
using System;                                      // Tipos básicos (DateTime, etc.)
using System.Linq;                                 // LINQ
using System.Threading.Tasks;                      // Soporte para async/await

namespace GymManagementSystem.Controllers
{
    // Restringe el acceso a los roles indicados
    [Authorize(Roles = "Admin,Manager,Trainer,Member")]
    public class GymClassesController : Controller
    {
        private readonly ApplicationDbContext _context;  // Contexto EF Core
        private readonly UserManager<Member> _userManager; // Administrador de usuarios Identity

        /// <summary>
        /// Constructor: recibe el contexto de datos y el administrador de usuarios.
        /// </summary>
        public GymClassesController(ApplicationDbContext context, UserManager<Member> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: GymClasses
        // Permite que los miembros vean la lista (además de Admin/Manager/Trainer)
        [Authorize(Roles = "Admin,Manager,Trainer,Member")] // Permite miembros
        public async Task<IActionResult> Index()
        {
            // Obtener el usuario actual y sus roles (si existe)
            var user = await _userManager.GetUserAsync(User);
            var userRoles = user != null
                ? await _userManager.GetRolesAsync(user)
                : new List<string>(); // Nota: requiere System.Collections.Generic si se agrega 'using' (no se modifica el código)

            // Consulta base, incluyendo relaciones necesarias
            IQueryable<GymClass> baseQuery = _context.GymClasses
                .Include(g => g.Instructor)
                .Include(g => g.MemberClasses);

            // Si es Member, filtra a clases futuras con cupo disponible
            if (userRoles.Contains("Member"))
            {
                baseQuery = baseQuery
                    .Where(g => g.Schedule > DateTime.Now) // Solo futuras
                    .Where(g => g.MemberClasses.Count(mc => !mc.IsCancelled) < g.MaxParticipants); // Con cupo
            }

            // Proyección a ViewModel con cálculo de cupos y estado
            var classes = await baseQuery
                .OrderBy(g => g.Schedule)
                .Select(g => new GymClassViewModel
                {
                    Id = g.Id,
                    Name = g.Name,
                    Description = g.Description,
                    Schedule = g.Schedule,
                    DurationMinutes = g.DurationMinutes,
                    MaxParticipants = g.MaxParticipants,
                    AvailableSpots = g.MaxParticipants - g.MemberClasses.Count(mc => !mc.IsCancelled),
                    Status = GymClassViewModel.GetStatus(
                        g.Schedule,
                        g.DurationMinutes,
                        g.MaxParticipants,
                        g.MemberClasses.Count(mc => !mc.IsCancelled)),
                    InstructorName = g.Instructor.FullName
                })
                .ToListAsync();

            return View(classes);
        }

        // GET: GymClasses/Details/5
        public async Task<IActionResult> Details(int id)
        {
            // Carga la clase con su instructor y reservas, incluyendo datos del miembro
            var gymClass = await _context.GymClasses
                .Include(g => g.Instructor)
                .Include(g => g.MemberClasses)
                    .ThenInclude(mc => mc.Member)
                .FirstOrDefaultAsync(g => g.Id == id);

            if (gymClass == null)
            {
                return NotFound();
            }

            // Calcular totales y estado de la clase
            var activeMembersCount = gymClass.MemberClasses.Count(mc => !mc.IsCancelled);
            var availableSpots = gymClass.MaxParticipants - activeMembersCount;
            var status = GetClassStatus(gymClass.Schedule, gymClass.DurationMinutes, gymClass.MaxParticipants, activeMembersCount);

            // Armar ViewModel de detalle
            var viewModel = new GymClassDetailViewModel
            {
                Id = gymClass.Id,
                Name = gymClass.Name,
                Description = gymClass.Description,
                Schedule = gymClass.Schedule,
                EndTime = gymClass.Schedule.AddMinutes(gymClass.DurationMinutes),
                DurationMinutes = gymClass.DurationMinutes,
                MaxParticipants = gymClass.MaxParticipants,
                AvailableSpots = availableSpots,
                Status = status,
                InstructorName = gymClass.Instructor?.FullName ?? "No asignado", // Manejo de null
                Attendees = gymClass.MemberClasses
                    .Where(mc => !mc.IsCancelled)
                    .OrderBy(mc => mc.BookingDate)
                    .Select(mc => new AttendeeViewModel
                    {
                        MemberId = mc.MemberId,
                        MemberName = mc.Member?.FullName ?? "Nombre no disponible", // Manejo de null
                        BookingDate = mc.BookingDate,
                        Attended = mc.Attended,
                        PhoneNumber = mc.Member?.PhoneNumber ?? string.Empty,
                        Email = mc.Member?.Email ?? string.Empty
                    })
                    .ToList(),
                CanEdit = User.IsInRole("Admin") || User.IsInRole("Manager"),
                CanCancel = gymClass.Schedule > DateTime.Now,
                CanMarkAttendance = gymClass.Schedule.Date == DateTime.Today
            };

            return View(viewModel);
        }

        /// <summary>
        /// Determina el estado de la clase según horario, duración y ocupación.
        /// </summary>
        private static string GetClassStatus(DateTime schedule, int duration, int maxParticipants, int currentParticipants)
        {
            var now = DateTime.Now;
            var endTime = schedule.AddMinutes(duration);

            if (now > endTime) return "Finalizada";
            if (now >= schedule && now <= endTime) return "En curso";
            if (currentParticipants >= maxParticipants) return "Llena";
            return "Disponible";
        }

        // GET: GymClasses/Create
        public async Task<IActionResult> Create()
        {
            try
            {
                // Obtener solo entrenadores activos (para mostrar mensaje si no hay)
                var trainers = await _context.Trainers
                    .Where(t => t.IsActive)
                    .OrderBy(t => t.LastName)
                    .ThenBy(t => t.Name)
                    .Select(t => new SelectListItem
                    {
                        Value = t.Id.ToString(),
                        Text = $"{t.LastName}, {t.Name} - {t.Specialization}"
                    })
                    .ToListAsync();

                // Si no hay entrenadores activos, redirige a su índice
                if (!trainers.Any())
                {
                    TempData["ErrorMessage"] = "No hay entrenadores activos disponibles. Por favor, cree al menos un entrenador primero.";
                    return RedirectToAction("Index", "Trainers");
                }

                // Modelo por defecto para la vista de creación
                var model = new GymClassCreateEditViewModel
                {
                    Trainers = await GetTrainersSelectList(),
                    Schedule = DateTime.Now.AddDays(1).Date.AddHours(18), // Próximo día a las 18:00
                    DurationMinutes = 60,
                    MaxParticipants = 15
                };

                return View(model);
            }
            catch (Exception ex)
            {
                // Log de error (aquí solo se escribe en consola)
                Console.WriteLine($"Error al cargar el formulario de creación: {ex.Message}");

                TempData["ErrorMessage"] = "Ocurrió un error al cargar el formulario. Por favor, intente nuevamente.";
                return RedirectToAction("Index");
            }
        }

        // POST: GymClasses/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(GymClassCreateEditViewModel model)
        {
            // Recargar lista de entrenadores para la vista en caso de error/validación
            model.Trainers = await GetTrainersSelectList();

            if (ModelState.IsValid)
            {
                // Validación: no permitir programar en el pasado
                if (model.Schedule < DateTime.Now)
                {
                    ModelState.AddModelError(nameof(model.Schedule), "La clase no puede programarse en el pasado");
                    model.Trainers = await GetTrainersSelectList();
                    return View(model);
                }

                // Construye la entidad desde el ViewModel
                var gymClass = new GymClass
                {
                    Name = model.Name,
                    Description = model.Description,
                    Schedule = model.Schedule,
                    DurationMinutes = model.DurationMinutes,
                    MaxParticipants = model.MaxParticipants,
                    InstructorId = model.InstructorId
                };

                _context.Add(gymClass);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = $"Clase '{gymClass.Name}' creada exitosamente";
                return RedirectToAction(nameof(Index));
            }

            // Si el modelo no es válido, regresar la vista con datos
            model.Trainers = await GetTrainersSelectList();
            return View(model);
        }

        // GET: GymClasses/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            // Buscar la clase a editar
            var gymClass = await _context.GymClasses.FindAsync(id);
            if (gymClass == null)
            {
                return NotFound();
            }

            // Cargar ViewModel con la información de la clase
            var model = new GymClassCreateEditViewModel
            {
                Id = gymClass.Id,
                Name = gymClass.Name,
                Description = gymClass.Description,
                Schedule = gymClass.Schedule,
                DurationMinutes = gymClass.DurationMinutes,
                MaxParticipants = gymClass.MaxParticipants,
                InstructorId = gymClass.InstructorId,
                Trainers = await GetTrainersSelectList(gymClass.InstructorId)
            };

            return View(model);
        }

        // POST: GymClasses/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, GymClassCreateEditViewModel model)
        {
            // Verificación de ruta/ID
            if (id != model.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Validación: no programar en el pasado
                    if (model.Schedule < DateTime.Now)
                    {
                        ModelState.AddModelError(nameof(model.Schedule), "La clase no puede programarse en el pasado");
                        model.Trainers = await GetTrainersSelectList(model.InstructorId);
                        return View(model);
                    }

                    // Cargar entidad original
                    var gymClass = await _context.GymClasses.FindAsync(id);
                    if (gymClass == null)
                    {
                        return NotFound();
                    }

                    // Mapear cambios
                    gymClass.Name = model.Name;
                    gymClass.Description = model.Description;
                    gymClass.Schedule = model.Schedule;
                    gymClass.DurationMinutes = model.DurationMinutes;
                    gymClass.MaxParticipants = model.MaxParticipants;
                    gymClass.InstructorId = model.InstructorId;

                    _context.Update(gymClass);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = $"Clase '{gymClass.Name}' actualizada exitosamente";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    // Verifica si aún existe
                    if (!GymClassExists(id))
                    {
                        return NotFound();
                    }
                    // Re-lanza la excepción si no es un caso de no existencia
                    throw;
                }
            }

            // Si el modelo no es válido, recarga lista de entrenadores y vuelve a la vista
            model.Trainers = await GetTrainersSelectList(model.InstructorId);
            return View(model);
        }

        // GET: GymClasses/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            // Carga la clase con su instructor y reservas
            var gymClass = await _context.GymClasses
                .Include(g => g.Instructor)
                .Include(g => g.MemberClasses)
                .FirstOrDefaultAsync(g => g.Id == id);

            if (gymClass == null)
            {
                return NotFound();
            }

            // Valida que no existan reservas activas
            if (gymClass.MemberClasses.Any(mc => !mc.IsCancelled))
            {
                TempData["ErrorMessage"] = "No se puede eliminar una clase con reservas activas";
                return RedirectToAction(nameof(Index));
            }

            return View(gymClass);
        }

        // POST: GymClasses/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            // Vuelve a cargar la clase para confirmar y validar reservas
            var gymClass = await _context.GymClasses
                .Include(g => g.MemberClasses)
                .FirstOrDefaultAsync(g => g.Id == id);

            if (gymClass == null)
            {
                return NotFound();
            }

            // Impide eliminar si hay reservas activas
            if (gymClass.MemberClasses.Any(mc => !mc.IsCancelled))
            {
                TempData["ErrorMessage"] = "No se puede eliminar una clase con reservas activas";
                return RedirectToAction(nameof(Index));
            }

            _context.GymClasses.Remove(gymClass);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"Clase '{gymClass.Name}' eliminada exitosamente";
            return RedirectToAction(nameof(Index));
        }

        // GET: GymClasses/Enroll/5
        // Permite a los miembros inscribirse a una clase
        [Authorize(Roles = "Member")]
        public async Task<IActionResult> Enroll(int id)
        {
            var userId = _userManager.GetUserId(User); // Id del usuario actual
            var gymClass = await _context.GymClasses.FindAsync(id);

            if (gymClass == null)
            {
                return NotFound();
            }

            // Verificar si ya está inscrito (y no cancelado)
            var existingEnrollment = await _context.MemberClasses
                .FirstOrDefaultAsync(mc => mc.MemberId == userId &&
                                          mc.GymClassId == id &&
                                          !mc.IsCancelled);

            if (existingEnrollment != null)
            {
                TempData["ErrorMessage"] = "Ya estás inscrito en esta clase";
                return RedirectToAction(nameof(Index));
            }

            // Verificar disponibilidad de cupos
            var currentParticipants = await _context.MemberClasses
                .CountAsync(mc => mc.GymClassId == id && !mc.IsCancelled);

            if (currentParticipants >= gymClass.MaxParticipants)
            {
                TempData["ErrorMessage"] = "La clase ya está llena";
                return RedirectToAction(nameof(Index));
            }

            // Crear reserva con valores predeterminados
            var memberClass = new MemberClass
            {
                MemberId = userId,
                GymClassId = id,
                BookingDate = DateTime.Now,
                Attended = false,
                IsCancelled = false,
                Feedback = string.Empty // Valor por defecto
            };

            _context.MemberClasses.Add(memberClass);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"¡Reserva confirmada para {gymClass.Name}!";
            return RedirectToAction(nameof(MyBookings)); // Redirigir a Mis Reservas
        }

        //
        // GET: Mis reservas del miembro autenticado
        [Authorize(Roles = "Member")]
        public async Task<IActionResult> MyBookings()
        {
            var userId = _userManager.GetUserId(User);

            // Consulta reservas activas del usuario
            var bookings = await _context.MemberClasses
                .Include(mc => mc.GymClass)
                    .ThenInclude(g => g.Instructor)
                .Where(mc => mc.MemberId == userId && !mc.IsCancelled)
                .Select(mc => new MemberBookingViewModel
                {
                    Id = mc.Id,
                    GymClassName = mc.GymClass.Name,
                    Schedule = mc.GymClass.Schedule,
                    Duration = mc.GymClass.DurationMinutes,
                    InstructorName = mc.GymClass.Instructor.FullName,
                    BookingDate = mc.BookingDate,
                    Attended = mc.Attended,
                    CanCancel = mc.GymClass.Schedule > DateTime.Now.AddHours(24) // Permitir cancelar hasta 24h antes
                })
                .OrderBy(b => b.Schedule)
                .ToListAsync();

            return View(bookings);
        }

        //
        // Comprueba existencia de una clase por Id
        private bool GymClassExists(int id)
        {
            return _context.GymClasses.Any(e => e.Id == id);
        }

        // Construye la lista de entrenadores activos para combos en vistas
        private async Task<List<SelectListItem>> GetTrainersSelectList(string selectedId = null)
        {
            return await _context.Trainers
                .Where(t => t.IsActive)
                .OrderBy(t => t.LastName)
                .ThenBy(t => t.Name)
                .Select(t => new SelectListItem
                {
                    Value = t.Id, // Id es string
                    Text = $"{t.LastName}, {t.Name} - {t.Specialization}",
                    Selected = t.Id == selectedId
                })
                .ToListAsync();
        }

        //
        // Cancelación de una reserva por parte del miembro
        [Authorize(Roles = "Member")]
        public async Task<IActionResult> CancelBooking(int id)
        {
            var userId = _userManager.GetUserId(User);

            // Carga la reserva solicitada perteneciente al usuario
            var booking = await _context.MemberClasses
                .Include(mc => mc.GymClass)
                .FirstOrDefaultAsync(mc => mc.Id == id && mc.MemberId == userId);

            if (booking == null)
            {
                TempData["ErrorMessage"] = "No se encontró la reserva.";
                return RedirectToAction(nameof(MyBookings));
            }

            // Regla: solo puede cancelar si faltan más de 24 horas
            if (booking.GymClass.Schedule <= DateTime.Now.AddHours(24))
            {
                TempData["ErrorMessage"] = "No puedes cancelar la reserva con menos de 24 horas de antelación.";
                return RedirectToAction(nameof(MyBookings));
            }

            booking.IsCancelled = true;
            _context.Update(booking);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"La reserva para la clase '{booking.GymClass.Name}' fue cancelada.";
            return RedirectToAction(nameof(MyBookings));
        }

        //
        // Sobrecarga auxiliar de estado (sin considerar cupos)
        private static string GetClassStatus(DateTime schedule, int duration)
        {
            var now = DateTime.Now;
            var endTime = schedule.AddMinutes(duration);

            if (now > endTime) return "Finalizada";
            if (now >= schedule && now <= endTime) return "En curso";
            return "Programada";
        }
    }
}
