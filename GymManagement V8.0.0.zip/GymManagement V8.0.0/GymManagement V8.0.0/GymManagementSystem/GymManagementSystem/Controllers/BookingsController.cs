﻿using GymManagementSystem.Areas.Identity.Data;
using GymManagementSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace GymManagementSystem.Controllers
{
    [Authorize(Roles = "Admin,Manager,Member")]

    public class BookingsController : Controller
    {
        public IActionResult MyBookings()
        {
            return RedirectToAction("MyBookings", "GymClasses");
        }
    }


}
