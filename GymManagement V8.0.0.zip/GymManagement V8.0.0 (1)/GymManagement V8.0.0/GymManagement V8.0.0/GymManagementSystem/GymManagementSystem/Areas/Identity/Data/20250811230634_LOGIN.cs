﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GymManagementSystem.Areas.Identity.Data
{
    /// <summary>
    /// Migración: LOGIN
    /// Esta migración modifica la tabla AspNetUsers para establecer
    /// un valor por defecto ("Basic") en la columna MembershipType.
    /// </summary>
    public partial class LOGIN : Migration
    {
        /// <summary>
        /// Método Up:
        /// Define los cambios que se aplicarán a la base de datos al ejecutar la migración.
        /// En este caso, se cambia la columna "MembershipType" de la tabla "AspNetUsers"
        /// para que tenga como valor por defecto "Basic".
        /// </summary>
        /// <param name="migrationBuilder">Objeto que construye las operaciones de migración</param>
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "MembershipType",           // Nombre de la columna a modificar
                table: "AspNetUsers",             // Nombre de la tabla
                nullable: false,                  // No permite valores nulos
                defaultValue: "Basic",            // Valor por defecto asignado
                oldClrType: typeof(string));      // Tipo de dato anterior
        }

        /// <summary>
        /// Método Down:
        /// Define las operaciones que revierten los cambios hechos en el método Up.
        /// En este caso, debería revertir la columna "MembershipType" a su estado anterior,
        /// pero actualmente está vacío y no aplica ninguna reversión.
        /// </summary>
        /// <param name="migrationBuilder">Objeto que construye las operaciones de migración</param>
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Aquí se revertiría el cambio realizado en Up si fuera necesario.
            // Por ejemplo: eliminar el valor por defecto asignado a "MembershipType".
        }
    }
}
