using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GymManagementSystem.Views.Account
{
    public class ChangePasswordModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
