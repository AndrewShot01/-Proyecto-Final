﻿using GymManagementSystem.Areas.Identity.Data;
using GymManagementSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GymManagementSystem.Controllers
{
    [Authorize(Roles = "Admin,Manager")]
    public class TrainersController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TrainersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Trainers
        public async Task<IActionResult> Index()
        {
            var trainers = await _context.Trainers
                .OrderBy(t => t.LastName)
                .ThenBy(t => t.Name)
                .Select(t => new TrainerViewModel
                {
                    Id = t.Id,
                    FullName = t.FullName,
                    Specialization = t.Specialization,
                    Email = t.Email,
                    Phone = t.Phone,
                    HireDate = t.HireDate,
                    IsActive = t.IsActive,
                    ActiveClassesCount = t.GymClasses.Count(g => g.Schedule > DateTime.Now)
                })
                .ToListAsync();

            return View(trainers);
        }
      


        // GET: Trainers/Create
        public IActionResult Create()
        {
            return View(new TrainerCreateEditViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TrainerCreateEditViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var trainer = new Trainer
                    {
                        Name = model.Name,
                        LastName = model.LastName,
                        Specialization = model.Specialization,
                        Email = model.Email,
                        Phone = model.Phone,
                        Bio = model.Bio,
                        HireDate = DateTime.Now,
                        IsActive = true
                    };

                    _context.Add(trainer);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = $"Entrenador {trainer.FullName} creado exitosamente";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", $"Error al guardar: {ex.Message}");
                }
            }

            // Si hay errores, mostrar la vista nuevamente
            return View(model);
        }


        // GET: Trainers/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }

            var trainer = await _context.Trainers.FindAsync(id);
            if (trainer == null)
            {
                return NotFound();
            }

            // En el método Edit (GET), cambia la asignación de Id en TrainerCreateEditViewModel
            var model = new TrainerCreateEditViewModel
            {
                Id = int.TryParse(trainer.Id, out var intId) ? intId : 0, // Conversión segura de string a int
                Name = trainer.Name,
                LastName = trainer.LastName,
                Specialization = trainer.Specialization,
                Email = trainer.Email,
                Phone = trainer.Phone,
                Bio = trainer.Bio
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, TrainerCreateEditViewModel model)
        {
            // Solución: Convertir model.Id a string para comparar correctamente
            if (id != model.Id.ToString())
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var trainer = await _context.Trainers.FindAsync(id);
                    if (trainer == null)
                    {
                        return NotFound();
                    }

                    trainer.Name = model.Name;
                    trainer.LastName = model.LastName;
                    trainer.Specialization = model.Specialization;
                    trainer.Email = model.Email;
                    trainer.Phone = model.Phone;
                    trainer.Bio = model.Bio;

                    _context.Update(trainer);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = $"Entrenador {trainer.FullName} actualizado exitosamente";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TrainerExists(id))
                    {
                        return NotFound();
                    }
                    throw;
                }
            }
            return View(model);
        }

        // GET: Trainers/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }

            var trainer = await _context.Trainers
                .Include(t => t.GymClasses)
                .FirstOrDefaultAsync(t => t.Id == id);

            if (trainer == null)
            {
                return NotFound();
            }

            if (trainer.GymClasses.Any())
            {
                TempData["ErrorMessage"] = $"No se puede eliminar a {trainer.FullName} porque tiene clases asignadas";
                return RedirectToAction(nameof(Index));
            }

            var viewModel = new TrainerViewModel
            {
                Id = trainer.Id,
                FullName = trainer.FullName,
                Specialization = trainer.Specialization,
                HireDate = trainer.HireDate,
                IsActive = trainer.IsActive
            };

            return View(viewModel);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var trainer = await _context.Trainers
                .Include(t => t.GymClasses)
                .FirstOrDefaultAsync(t => t.Id == id);

            if (trainer == null)
            {
                return NotFound();
            }

            if (trainer.GymClasses.Any())
            {
                TempData["ErrorMessage"] = $"No se puede eliminar a {trainer.FullName} porque tiene clases asignadas";
                return RedirectToAction(nameof(Index));
            }

            _context.Trainers.Remove(trainer);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"Entrenador {trainer.FullName} eliminado exitosamente";
            return RedirectToAction(nameof(Index));
        }

        private bool TrainerExists(string id)
        {
            return _context.Trainers.Any(e => e.Id == id);
        }
    }
}