﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// Representa un equipo del gimnasio, incluyendo su información de mantenimiento y estado.
    /// </summary>
    public class Equipment
    {
        /// <summary>
        /// Identificador único del equipo.
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Nombre del equipo (por ejemplo: Caminadora, Bicicleta, Mancuernas).
        /// </summary>
        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        /// <summary>
        /// Descripción detallada del equipo.
        /// </summary>
        [Required]
        public string Description { get; set; }

        /// <summary>
        /// Fecha de compra del equipo.
        /// </summary>
        [Required]
        public DateTime PurchaseDate { get; set; }

        /// <summary>
        /// Fecha de último mantenimiento realizado al equipo.
        /// </summary>
        [Required]
        public DateTime MaintenanceDate { get; set; }

        /// <summary>
        /// Estado actual del equipo.
        /// Valores posibles: "Operational", "Maintenance", "Out of Service".
        /// </summary>
        [Required]
        public string Status { get; set; } // "Operational", "Maintenance", "Out of Service"
    }
}
