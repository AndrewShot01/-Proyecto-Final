﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// Representa a un miembro del gimnasio.
    /// Hereda de IdentityUser, por lo que ya incluye propiedades como:
    /// Id, UserName, Email, PhoneNumber, PasswordHash, etc.
    /// </summary>
    public class Member : IdentityUser
    {
        /// <summary>
        /// Nombre del miembro.
        /// </summary>
        [Required(ErrorMessage = "El nombre es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        /// <summary>
        /// Apellido del miembro.
        /// </summary>
        [Required(ErrorMessage = "El apellido es obligatorio")]
        [StringLength(100, ErrorMessage = "El apellido no puede exceder 100 caracteres")]
        [Display(Name = "Apellido")]
        public string LastName { get; set; }

        /// <summary>
        /// Nombre completo generado automáticamente combinando
        /// el nombre y apellido. No se mapea a la base de datos.
        /// </summary>
        [NotMapped]
        public string FullName => $"{Name} {LastName}";

        /// <summary>
        /// Fecha en que el miembro se registró.
        /// </summary>
        [Required(ErrorMessage = "La fecha de registro es obligatoria")]
        [DataType(DataType.Date)]
        [Display(Name = "Fecha de Registro")]
        public DateTime RegistrationDate { get; set; } = DateTime.Now;

        /// <summary>
        /// Fecha de expiración de la membresía (si aplica).
        /// Puede ser nula.
        /// </summary>
        [DataType(DataType.Date)]
        [Display(Name = "Expiración de Membresía")]
        public DateTime? MembershipExpiration { get; set; }

        /// <summary>
        /// Tipo de membresía del usuario.
        /// Ejemplos: "Basic", "Premium", "VIP".
        /// </summary>
        [Required(ErrorMessage = "El tipo de membresía es obligatorio")]
        [Display(Name = "Tipo de Membresía")]
        public string MembershipType { get; set; }

        /// <summary>
        /// Relación de navegación con las clases del gimnasio
        /// a las que el miembro está inscrito.
        /// </summary>
        public virtual ICollection<MemberClass> MemberClasses { get; set; }
    }
}
