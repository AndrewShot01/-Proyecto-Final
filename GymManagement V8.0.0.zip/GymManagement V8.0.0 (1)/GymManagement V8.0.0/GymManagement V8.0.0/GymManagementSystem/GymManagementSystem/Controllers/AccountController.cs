﻿using GymManagementSystem.Areas.Identity.Models; // Asegúrate que Member esté aquí
using GymManagementSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace GymManagementSystem.Controllers
{
    /// <summary>
    /// Controlador de cuentas (registro, inicio/cierre de sesión, perfil y contraseña).
    /// Usa Identity con la entidad <see cref="Member"/>.
    /// </summary>
    public class AccountController : Controller
    {
        // Administra operaciones de usuarios (crear, actualizar, roles, etc.)
        private readonly UserManager<Member> _userManager;

        // Administra operaciones de autenticación (login, logout, 2FA, etc.)
        private readonly SignInManager<Member> _signInManager;

        /// <summary>
        /// Constructor que recibe los administradores de usuarios y de inicio de sesión.
        /// </summary>
        public AccountController(
            UserManager<Member> userManager,
            SignInManager<Member> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        /// <summary>
        /// GET: Muestra la vista de inicio de sesión.
        /// </summary>
        /// <param name="returnUrl">URL a la que se redirigirá después de iniciar sesión.</param>
        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl; // Guarda la URL de retorno para usarla en la vista
            return View();
        }

        /// <summary>
        /// POST: Procesa el inicio de sesión con credenciales.
        /// </summary>
        /// <param name="model">Modelo con Email, Password y RememberMe.</param>
        /// <param name="returnUrl">URL de retorno tras autenticación exitosa.</param>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
        {
            returnUrl ??= Url.Content("~/");         // Si no hay returnUrl, ir a la raíz
            ViewData["ReturnUrl"] = returnUrl;       // Mantener la returnUrl para la vista

            if (ModelState.IsValid)
            {
                // Intenta iniciar sesión con email y contraseña
                var result = await _signInManager.PasswordSignInAsync(
                    model.Email, model.Password, model.RememberMe, lockoutOnFailure: false);

                if (result.Succeeded)
                {
                    // Redirige explícitamente a Home/Index
                    return RedirectToAction("Index", "Home");
                }

                if (result.RequiresTwoFactor)
                {
                    // Si requiere 2FA, redirige al flujo de 2FA
                    return RedirectToPage("./LoginWith2fa", new { ReturnUrl = returnUrl, RememberMe = model.RememberMe });
                }

                if (result.IsLockedOut)
                {
                    // Si la cuenta está bloqueada, redirige a Lockout
                    return RedirectToPage("./Lockout");
                }

                // Credenciales inválidas: agrega error de modelo
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
            }

            // Si algo falló, regresa a la vista con el modelo para mostrar errores
            return View(model);
        }

        /// <summary>
        /// GET: Muestra la vista de registro.
        /// </summary>
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        /// <summary>
        /// POST: Procesa el registro de un nuevo usuario.
        /// </summary>
        /// <param name="model">Datos de registro (Email, Password, Name, LastName, MembershipType, etc.).</param>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Construye la entidad Member con los datos del formulario
                var user = new Member
                {
                    UserName = model.Email,
                    Email = model.Email,
                    Name = model.Name,
                    LastName = model.LastName,
                    RegistrationDate = DateTime.Now,
                    MembershipType = model.MembershipType // Asigna el tipo de membresía
                };

                // Crea el usuario con la contraseña proporcionada
                var result = await _userManager.CreateAsync(user, model.Password);

                if (result.Succeeded)
                {
                    // Asignar rol básico por defecto
                    await _userManager.AddToRoleAsync(user, "Member");

                    // Inicia sesión al usuario recién creado
                    await _signInManager.SignInAsync(user, isPersistent: false);
                    return RedirectToAction("Index", "Home");
                }

                // Si hubo errores al crear el usuario, agregarlos al ModelState
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }

            // Si llegamos aquí, algo falló: volver a mostrar el formulario con validaciones
            return View(model);
        }

        /// <summary>
        /// POST: Cierra la sesión del usuario actual.
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync(); // Cierra sesión
            return RedirectToAction("Index", "Home");
        }

        /// <summary>
        /// GET: Vista para acceso denegado.
        /// </summary>
        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }

        /// <summary>
        /// GET: Muestra el perfil del usuario autenticado.
        /// </summary>
        [Authorize]
        public async Task<IActionResult> Profile()
        {
            var user = await _userManager.GetUserAsync(User); // Obtiene el usuario actual
            var model = new ProfileViewModel
            {
                Email = user.Email,
                Name = user.Name,
                LastName = user.LastName
                // Agrega más propiedades según tu modelo Member
            };
            return View(model);
        }

        /// <summary>
        /// POST: Actualiza el perfil del usuario autenticado.
        /// </summary>
        /// <param name="model">Modelo con los datos editados del perfil.</param>
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Profile(ProfileViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.GetUserAsync(User); // Usuario actual
                user.Name = model.Name;
                user.LastName = model.LastName;
                // Actualiza otros campos según sea necesario

                var result = await _userManager.UpdateAsync(user);
                if (result.Succeeded)
                {
                    TempData["SuccessMessage"] = "Perfil actualizado correctamente";
                    return RedirectToAction("Profile");
                }

                // Agrega errores de actualización al ModelState
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }
            return View(model); // Devuelve la vista con validaciones
        }

        /// <summary>
        /// GET: Muestra la vista para cambiar la contraseña.
        /// </summary>
        [Authorize]
        public IActionResult ChangePassword()
        {
            return View();
        }

        /// <summary>
        /// POST: Cambia la contraseña del usuario autenticado.
        /// </summary>
        /// <param name="model">Modelo con contraseña actual y nueva.</param>
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.GetUserAsync(User); // Usuario actual
                var result = await _userManager.ChangePasswordAsync(user, model.CurrentPassword, model.NewPassword);

                if (result.Succeeded)
                {
                    await _signInManager.RefreshSignInAsync(user); // Refresca la sesión
                    TempData["SuccessMessage"] = "Contraseña cambiada exitosamente";
                    return RedirectToAction("Profile");
                }

                // Agrega errores de cambio de contraseña al ModelState
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }
            return View(model); // Devuelve la vista con validaciones
        }


        //
        //  (Separadores en el código original)
        //


        /// <summary>
        /// GET: Muestra la vista de inicio de sesión.
        /// Nota: Existe otra acción <c>Login(string? returnUrl)</c> definida arriba.
        /// </summary>
        public IActionResult Login()
        {
            if (User.Identity.IsAuthenticated)
            {
                // Si ya está autenticado, redirige al inicio
                return RedirectToAction("Index", "Home");
            }
            return View(); // Muestra la vista de login
        }
    }
}
