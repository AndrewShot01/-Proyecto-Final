﻿using GymManagementSystem.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GymManagementSystem.Controllers
{
    [Authorize(Roles = "Admin")]
    public class MembersController : Controller
    {
        private readonly UserManager<Member> _userManager;

        public MembersController(UserManager<Member> userManager)
        {
            _userManager = userManager;
        }

        // GET: Members
        public async Task<IActionResult> Index()
        {
            var members = await _userManager.Users
                .OrderBy(m => m.Name)
                .ToListAsync();
            return View(members);
        }

        // GET: Members/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var member = await _userManager.FindByIdAsync(id);
            if (member == null)
            {
                return NotFound();
            }

            return View(member);
        }

        // GET: Members/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Members/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(MemberViewModel model)
        {
            if (ModelState.IsValid)
            {
                var member = new Member
                {
                    UserName = model.Email,
                    Email = model.Email,
                    Name = model.Name,
                    LastName = model.LastName,
                    PhoneNumber = model.Phone,
                    MembershipType = model.MembershipType,
                    RegistrationDate = DateTime.Now,
                    EmailConfirmed = true
                };

                var result = await _userManager.CreateAsync(member, model.Password);

                if (result.Succeeded)
                {
                    await _userManager.AddToRoleAsync(member, "Member");
                    TempData["SuccessMessage"] = $"Member {member.FullName} created successfully";
                    return RedirectToAction(nameof(Index));
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }
            return View(model);
        }

        // GET: Members/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var member = await _userManager.FindByIdAsync(id);
            if (member == null)
            {
                return NotFound();
            }

            var model = new MemberEditViewModel
            {
                Id = member.Id,
                Name = member.Name,
                LastName = member.LastName,
                Email = member.Email,
                Phone = member.PhoneNumber,
                MembershipType = member.MembershipType,
                MembershipExpiration = member.MembershipExpiration
            };

            return View(model);
        }

        // POST: Members/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, MemberEditViewModel model)
        {
            if (id != model.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var member = await _userManager.FindByIdAsync(id);
                    if (member == null)
                    {
                        return NotFound();
                    }

                    member.Name = model.Name;
                    member.LastName = model.LastName;
                    member.Email = model.Email;
                    member.UserName = model.Email;
                    member.PhoneNumber = model.Phone;
                    member.MembershipType = model.MembershipType;
                    member.MembershipExpiration = model.MembershipExpiration;

                    var result = await _userManager.UpdateAsync(member);
                    if (result.Succeeded)
                    {
                        TempData["SuccessMessage"] = "Miembro actualizado exitosamente";
                        return RedirectToAction(nameof(Index));
                    }

                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError(string.Empty, error.Description);
                    }
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await MemberExists(model.Id))
                    {
                        return NotFound();
                    }
                    throw;
                }
            }
            return View(model);
        }


        // GET: Members/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var member = await _userManager.FindByIdAsync(id);
            if (member == null)
            {
                return NotFound();
            }

            return View(member);
        }

        // POST: Members/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var member = await _userManager.FindByIdAsync(id);
            if (member != null)
            {
                var result = await _userManager.DeleteAsync(member);
                if (result.Succeeded)
                {
                    TempData["SuccessMessage"] = "Member deleted successfully";
                }
                else
                {
                    TempData["ErrorMessage"] = "Error deleting member";
                }
            }
            return RedirectToAction(nameof(Index));
        }

        private async Task<bool> MemberExists(string id)
        {
            return await _userManager.FindByIdAsync(id) != null;
        }
    }
}
