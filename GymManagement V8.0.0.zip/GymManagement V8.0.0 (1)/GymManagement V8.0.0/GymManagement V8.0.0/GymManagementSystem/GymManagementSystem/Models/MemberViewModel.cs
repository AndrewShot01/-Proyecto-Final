﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// ViewModel que representa la información necesaria para registrar o mostrar un miembro.
    /// </summary>
    public class MemberViewModel
    {
        /// <summary>
        /// Nombre del miembro.
        /// </summary>
        [Required(ErrorMessage = "El nombre es obligatorio")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        /// <summary>
        /// Apellido del miembro.
        /// </summary>
        [Required(ErrorMessage = "El apellido es obligatorio")]
        [Display(Name = "Apellido")]
        public string LastName { get; set; }

        /// <summary>
        /// Correo electrónico del miembro.
        /// </summary>
        [Required(ErrorMessage = "El email es obligatorio")]
        [EmailAddress(ErrorMessage = "Formato de email inválido")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        /// <summary>
        /// Número de teléfono del miembro.
        /// </summary>
        [Required(ErrorMessage = "El teléfono es obligatorio")]
        [Phone(ErrorMessage = "Formato de teléfono inválido")]
        [Display(Name = "Teléfono")]
        public string Phone { get; set; }

        /// <summary>
        /// Contraseña para la cuenta del miembro.
        /// </summary>
        [Required(ErrorMessage = "La contraseña es obligatoria")]
        [DataType(DataType.Password)]
        [Display(Name = "Contraseña")]
        public string Password { get; set; }

        /// <summary>
        /// Tipo de membresía asignada al miembro (ejemplo: Basic, Premium, VIP).
        /// </summary>
        [Required(ErrorMessage = "El tipo de membresía es obligatorio")]
        [Display(Name = "Tipo de Membresía")]
        public string MembershipType { get; set; }

        /// <summary>
        /// Fecha en la que expira la membresía.
        /// Puede ser nula si no se ha definido.
        /// </summary>
        [DataType(DataType.Date)]
        [Display(Name = "Fecha de Expiración")]
        public DateTime? MembershipExpiration { get; set; }
    }
}
