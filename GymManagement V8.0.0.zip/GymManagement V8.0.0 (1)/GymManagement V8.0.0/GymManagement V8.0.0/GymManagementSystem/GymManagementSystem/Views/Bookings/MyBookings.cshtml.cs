using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GymManagementSystem.Views.Bookings
{
    public class MyBookingsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
