﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GymManagementSystem.Models
{
    public class Member : IdentityUser  // Hereda de IdentityUser (ya incluye Id, Email, PhoneNumber, etc.)
    {
        [Required(ErrorMessage = "El nombre es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        [Required(ErrorMessage = "El apellido es obligatorio")]
        [StringLength(100, ErrorMessage = "El apellido no puede exceder 100 caracteres")]
        [Display(Name = "Apellido")]
        public string LastName { get; set; }

        [NotMapped]
        public string FullName => $"{Name} {LastName}";


        // Email y PhoneNumber ya vienen de IdentityUser (no necesitas duplicarlos)
        // Password se maneja con UserManager (no lo guardes en el modelo)

        [Required(ErrorMessage = "La fecha de registro es obligatoria")]
        [DataType(DataType.Date)]
        [Display(Name = "Fecha de Registro")]
        public DateTime RegistrationDate { get; set; } = DateTime.Now;

        [DataType(DataType.Date)]
        [Display(Name = "Expiración de Membresía")]
        public DateTime? MembershipExpiration { get; set; }

        [Required(ErrorMessage = "El tipo de membresía es obligatorio")]
        [Display(Name = "Tipo de Membresía")]
        public string MembershipType { get; set; } // "Basic", "Premium", "VIP"

        // Navigation property
        public virtual ICollection<MemberClass> MemberClasses { get; set; }

        // Eliminamos UserId y ApplicationUser (son redundantes con Identity)
    }
}
