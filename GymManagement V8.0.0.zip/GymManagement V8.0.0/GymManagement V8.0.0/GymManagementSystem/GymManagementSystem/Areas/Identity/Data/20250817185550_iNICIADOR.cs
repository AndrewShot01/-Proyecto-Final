﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GymManagementSystem.Areas.Identity.Data
{
    /// <inheritdoc />
    public partial class iNICIADOR : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
