﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// Representa la relación entre un miembro y una clase de gimnasio.
    /// Incluye información sobre la reserva, asistencia, calificación y estado de cancelación.
    /// </summary>
    public class MemberClass
    {
        /// <summary>
        /// Identificador único de la relación (reserva).
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Identificador del miembro (vinculado a IdentityUser).
        /// </summary>
        [Required]
        [Display(Name = "Miembro")]
        public string MemberId { get; set; } // string para coincidir con Identity

        /// <summary>
        /// Identificador de la clase de gimnasio.
        /// </summary>
        [Required]
        [Display(Name = "Clase")]
        public int GymClassId { get; set; }

        /// <summary>
        /// Fecha en la que se realizó la reserva.
        /// </summary>
        [Display(Name = "Fecha de Reserva")]
        [DataType(DataType.DateTime)]
        public DateTime BookingDate { get; set; } = DateTime.Now;

        /// <summary>
        /// Indica si el miembro asistió a la clase.
        /// </summary>
        [Display(Name = "Asistió")]
        public bool Attended { get; set; } = false;

        /// <summary>
        /// Calificación otorgada por el miembro a la clase (1 a 5).
        /// </summary>
        [Display(Name = "Calificación")]
        [Range(1, 5, ErrorMessage = "La calificación debe estar entre 1 y 5")]
        public int? Rating { get; set; }

        /// <summary>
        /// Comentarios del miembro sobre la clase.
        /// </summary>
        [Display(Name = "Comentarios")]
        [StringLength(500, ErrorMessage = "Los comentarios no pueden exceder los 500 caracteres")]
        public string Feedback { get; set; } = string.Empty;

        /// <summary>
        /// Indica si la reserva fue cancelada.
        /// </summary>
        [Display(Name = "Cancelada")]
        public bool IsCancelled { get; set; } = false;

        /// <summary>
        /// Fecha en la que se canceló la reserva (si aplica).
        /// </summary>
        [Display(Name = "Fecha de Cancelación")]
        [DataType(DataType.DateTime)]
        public DateTime? CancellationDate { get; set; }

        // ================== Relaciones ==================

        /// <summary>
        /// Referencia al miembro que realizó la reserva.
        /// </summary>
        [ForeignKey("MemberId")]
        [Display(Name = "Miembro")]
        public virtual Member Member { get; set; }

        /// <summary>
        /// Referencia a la clase reservada.
        /// </summary>
        [ForeignKey("GymClassId")]
        [Display(Name = "Clase")]
        public virtual GymClass GymClass { get; set; }
    }
}
