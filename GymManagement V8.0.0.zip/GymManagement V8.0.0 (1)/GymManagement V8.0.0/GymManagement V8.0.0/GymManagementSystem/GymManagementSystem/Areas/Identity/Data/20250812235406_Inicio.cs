﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GymManagementSystem.Areas.Identity.Data
{
    /// <summary>
    /// Migración: Inicio
    /// Esta migración fue creada como base inicial. 
    /// Actualmente no contiene operaciones en los métodos Up ni Down.
    /// </summary>
    public partial class Inicio : Migration
    {
        /// <summary>
        /// Método Up:
        /// Aquí se definen los cambios que se aplicarán a la base de datos
        /// al ejecutar la migración.
        /// En este caso está vacío porque no se han definido modificaciones.
        /// </summary>
        /// <param name="migrationBuilder">Objeto utilizado para construir las operaciones de migración</param>
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Aquí se agregarían las operaciones para modificar la base de datos,
            // como creación de tablas, columnas, índices, etc.
        }

        /// <summary>
        /// Método Down:
        /// Aquí se definen las operaciones necesarias para revertir los cambios 
        /// hechos en el método Up, en caso de deshacer la migración.
        /// En este caso está vacío porque no se han definido cambios en Up.
        /// </summary>
        /// <param name="migrationBuilder">Objeto utilizado para construir las operaciones de migración</param>
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Aquí se agregarían las instrucciones para revertir los cambios
            // aplicados en el método Up.
        }
    }
}
