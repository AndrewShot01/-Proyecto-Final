﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GymManagementSystem.Models
{
    public class MemberClass
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Miembro")]
        public string MemberId { get; set; } // Cambiado de int a string para coincidir con Identity

        [Required]
        [Display(Name = "Clase")]
        public int GymClassId { get; set; }

        [Display(Name = "Fecha de Reserva")]
        [DataType(DataType.DateTime)]
        public DateTime BookingDate { get; set; } = DateTime.Now;

        [Display(Name = "Asistió")]
        public bool Attended { get; set; } = false;

        [Display(Name = "Calificación")]
        [Range(1, 5, ErrorMessage = "La calificación debe estar entre 1 y 5")]
        public int? Rating { get; set; }

        [Display(Name = "Comentarios")]
        [StringLength(500, ErrorMessage = "Los comentarios no pueden exceder los 500 caracteres")]
        public string Feedback { get; set; } = string.Empty;
        

        [Display(Name = "Cancelada")]
        public bool IsCancelled { get; set; } = false;

        [Display(Name = "Fecha de Cancelación")]
        [DataType(DataType.DateTime)]
        public DateTime? CancellationDate { get; set; }

        // Relaciones
        [ForeignKey("MemberId")]
        [Display(Name = "Miembro")]
        public virtual Member Member { get; set; }

        [ForeignKey("GymClassId")]
        [Display(Name = "Clase")]
        public virtual GymClass GymClass { get; set; }
    }
}