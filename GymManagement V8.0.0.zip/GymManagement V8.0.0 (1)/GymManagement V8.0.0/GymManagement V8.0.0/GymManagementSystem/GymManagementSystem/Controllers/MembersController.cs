﻿using GymManagementSystem.Models;            // Modelos del dominio (Member, ViewModels, etc.)
using Microsoft.AspNetCore.Authorization;    // Atributos de autorización [Authorize]
using Microsoft.AspNetCore.Identity;         // UserManager para gestión de usuarios Identity
using Microsoft.AspNetCore.Mvc;              // Tipos base de MVC (Controller, IActionResult)
using Microsoft.EntityFrameworkCore;         // Extensiones EF Core (ToListAsync, etc.)
using System;                                 // Tipos base (DateTime)
using System.Linq;                            // LINQ
using System.Threading.Tasks;                 // Soporte async/await

namespace GymManagementSystem.Controllers
{
    /// <summary>
    /// Controlador para administración de miembros (CRUD).
    /// Accesible únicamente por el rol "Admin".
    /// </summary>
    [Authorize(Roles = "Admin")]
    public class MembersController : Controller
    {
        private readonly UserManager<Member> _userManager; // Servicio de Identity para operar sobre usuarios

        /// <summary>
        /// Constructor que inyecta el <see cref="UserManager{TUser}"/> de <see cref="Member"/>.
        /// </summary>
        public MembersController(UserManager<Member> userManager)
        {
            _userManager = userManager;
        }

        /// <summary>
        /// Lista todos los miembros ordenados por nombre.
        /// </summary>
        /// <returns>Vista con la lista de miembros.</returns>
        // GET: Members
        public async Task<IActionResult> Index()
        {
            var members = await _userManager.Users
                .OrderBy(m => m.Name)
                .ToListAsync();
            return View(members);
        }

        /// <summary>
        /// Muestra los detalles de un miembro por su identificador.
        /// </summary>
        /// <param name="id">Id del miembro.</param>
        /// <returns>Vista de detalles o NotFound si no existe.</returns>
        // GET: Members/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var member = await _userManager.FindByIdAsync(id);
            if (member == null)
            {
                return NotFound();
            }

            return View(member);
        }

        /// <summary>
        /// Muestra el formulario de creación de un nuevo miembro.
        /// </summary>
        /// <returns>Vista Create.</returns>
        // GET: Members/Create
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Crea un nuevo miembro a partir del modelo recibido.
        /// Asigna rol "Member" por defecto.
        /// </summary>
        /// <param name="model">Datos del nuevo miembro.</param>
        /// <returns>Redirección al índice o vista con errores de validación.</returns>
        // POST: Members/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(MemberViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Construcción del objeto Member desde el ViewModel
                var member = new Member
                {
                    UserName = model.Email,
                    Email = model.Email,
                    Name = model.Name,
                    LastName = model.LastName,
                    PhoneNumber = model.Phone,
                    MembershipType = model.MembershipType,
                    RegistrationDate = DateTime.Now,
                    EmailConfirmed = true // Marca el correo como confirmado
                };

                // Creación del usuario con contraseña
                var result = await _userManager.CreateAsync(member, model.Password);

                if (result.Succeeded)
                {
                    // Asigna el rol por defecto
                    await _userManager.AddToRoleAsync(member, "Member");
                    TempData["SuccessMessage"] = $"Member {member.FullName} created successfully";
                    return RedirectToAction(nameof(Index));
                }

                // Agrega errores de Identity al ModelState para mostrarlos en la vista
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }
            // Si el modelo no es válido, permanece en la vista y muestra validaciones
            return View(model);
        }

        /// <summary>
        /// Muestra el formulario para editar un miembro existente.
        /// </summary>
        /// <param name="id">Id del miembro a editar.</param>
        /// <returns>Vista de edición o NotFound si no existe.</returns>
        // GET: Members/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var member = await _userManager.FindByIdAsync(id);
            if (member == null)
            {
                return NotFound();
            }

            // Mapea la entidad a un ViewModel de edición
            var model = new MemberEditViewModel
            {
                Id = member.Id,
                Name = member.Name,
                LastName = member.LastName,
                Email = member.Email,
                Phone = member.PhoneNumber,
                MembershipType = member.MembershipType,
                MembershipExpiration = member.MembershipExpiration
            };

            return View(model);
        }

        /// <summary>
        /// Actualiza los datos de un miembro existente.
        /// </summary>
        /// <param name="id">Id del miembro (ruta).</param>
        /// <param name="model">Modelo con los datos editados.</param>
        /// <returns>Redirección al índice o vista con errores.</returns>
        // POST: Members/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, MemberEditViewModel model)
        {
            if (id != model.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var member = await _userManager.FindByIdAsync(id);
                    if (member == null)
                    {
                        return NotFound();
                    }

                    // Actualiza campos permitidos
                    member.Name = model.Name;
                    member.LastName = model.LastName;
                    member.Email = model.Email;
                    member.UserName = model.Email;
                    member.PhoneNumber = model.Phone;
                    member.MembershipType = model.MembershipType;
                    member.MembershipExpiration = model.MembershipExpiration;

                    var result = await _userManager.UpdateAsync(member);
                    if (result.Succeeded)
                    {
                        TempData["SuccessMessage"] = "Miembro actualizado exitosamente";
                        return RedirectToAction(nameof(Index));
                    }

                    // Muestra errores de actualización
                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError(string.Empty, error.Description);
                    }
                }
                catch (DbUpdateConcurrencyException)
                {
                    // Si el recurso ya no existe, devuelve NotFound
                    if (!await MemberExists(model.Id))
                    {
                        return NotFound();
                    }
                    // Si fue otra causa, propaga la excepción
                    throw;
                }
            }
            // Si el modelo no es válido, vuelve a la vista con validaciones
            return View(model);
        }

        /// <summary>
        /// Muestra la confirmación de eliminación de un miembro.
        /// </summary>
        /// <param name="id">Id del miembro.</param>
        /// <returns>Vista de confirmación o NotFound.</returns>
        // GET: Members/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var member = await _userManager.FindByIdAsync(id);
            if (member == null)
            {
                return NotFound();
            }

            return View(member);
        }

        /// <summary>
        /// Elimina un miembro definitivamente.
        /// </summary>
        /// <param name="id">Id del miembro a eliminar.</param>
        /// <returns>Redirección al índice con mensaje de resultado.</returns>
        // POST: Members/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var member = await _userManager.FindByIdAsync(id);
            if (member != null)
            {
                var result = await _userManager.DeleteAsync(member);
                if (result.Succeeded)
                {
                    TempData["SuccessMessage"] = "Member deleted successfully";
                }
                else
                {
                    TempData["ErrorMessage"] = "Error deleting member";
                }
            }
            return RedirectToAction(nameof(Index));
        }

        /// <summary>
        /// Verifica si existe un miembro por Id.
        /// </summary>
        private async Task<bool> MemberExists(string id)
        {
            return await _userManager.FindByIdAsync(id) != null;
        }
    }
}
