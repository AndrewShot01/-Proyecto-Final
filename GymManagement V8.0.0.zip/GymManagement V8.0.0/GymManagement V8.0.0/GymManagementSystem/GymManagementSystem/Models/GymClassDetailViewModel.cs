﻿using GymManagementSystem.Areas.Identity.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    public class GymClassDetailViewModel
    {
        public int Id { get; set; }

        [Display(Name = "Nombre de Clase")]
        public string Name { get; set; }

        [Display(Name = "Descripción")]
        public string Description { get; set; }

        [Display(Name = "Fecha y Hora")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm}")]
        public DateTime Schedule { get; set; }

        [Display(Name = "Hora de Finalización")]
        [DisplayFormat(DataFormatString = "{0:HH:mm}")]
        public DateTime EndTime { get; set; }

        [Display(Name = "Duración (minutos)")]
        public int DurationMinutes { get; set; }

        [Display(Name = "Máximo de Participantes")]
        public int MaxParticipants { get; set; }

        [Display(Name = "Cupos Disponibles")]
        public int AvailableSpots { get; set; }

        [Display(Name = "Estado")]
        public string Status { get; set; }

        [Display(Name = "Instructor")]
        public string InstructorName { get; set; }

        [Display(Name = "ID del Instructor")]
        public string InstructorId { get; set; }

        // Información de asistencia
        public List<AttendeeViewModel> Attendees { get; set; } = new List<AttendeeViewModel>();

        // Estadísticas
        [Display(Name = "Total Inscritos")]
        public int TotalAttendees => Attendees.Count;

        [Display(Name = "Asistencia Confirmada")]
        public int ConfirmedAttendance => Attendees.Count(a => a.Attended);

        [Display(Name = "Porcentaje de Asistencia")]
        [DisplayFormat(DataFormatString = "{0:P0}")]
        public double AttendancePercentage => TotalAttendees > 0 ? (double)ConfirmedAttendance / TotalAttendees : 0;

        // Propiedades para acciones
        public bool CanEdit { get; set; }
        public bool CanCancel { get; set; }
        public bool CanMarkAttendance { get; set; }
    }

    
}
