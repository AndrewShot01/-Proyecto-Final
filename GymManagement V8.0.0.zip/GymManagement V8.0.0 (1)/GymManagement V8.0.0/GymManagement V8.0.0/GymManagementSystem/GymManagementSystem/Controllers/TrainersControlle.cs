﻿using GymManagementSystem.Areas.Identity.Data;   // Acceso al ApplicationDbContext (EF Core) y entidades del área Identity
using GymManagementSystem.Models;                // Modelos y ViewModels usados por el controlador
using Microsoft.AspNetCore.Authorization;        // Atributos de autorización [Authorize]
using Microsoft.AspNetCore.Mvc;                  // Tipos base MVC (Controller, IActionResult)
using Microsoft.EntityFrameworkCore;             // Extensiones EF Core (Include, ThenInclude, ToListAsync, etc.)
using System;                                    // Tipos base (DateTime, etc.)
using System.Linq;                               // LINQ (OrderBy, Where, Any, etc.)
using System.Threading.Tasks;                    // Soporte para async/await

namespace GymManagementSystem.Controllers
{
    /// <summary>
    /// Controlador para la gestión de entrenadores (Trainers).
    /// Restringido a los roles "Admin" y "Manager".
    /// </summary>
    [Authorize(Roles = "Admin,Manager")]
    public class TrainersController : Controller
    {
        private readonly ApplicationDbContext _context; // Contexto de base de datos EF Core

        /// <summary>
        /// Constructor. Inyecta el contexto de datos.
        /// </summary>
        /// <param name="context">Instancia de <see cref="ApplicationDbContext"/>.</param>
        public TrainersController(ApplicationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Lista de entrenadores con datos básicos y conteo de clases activas.
        /// </summary>
        /// <returns>Vista con colección de <see cref="TrainerViewModel"/>.</returns>
        // GET: Trainers
        public async Task<IActionResult> Index()
        {
            var trainers = await _context.Trainers
                .OrderBy(t => t.LastName)                          // Orden por apellido
                .ThenBy(t => t.Name)                               // Luego por nombre
                .Select(t => new TrainerViewModel
                {
                    Id = t.Id,
                    FullName = t.FullName,
                    Specialization = t.Specialization,
                    Email = t.Email,
                    Phone = t.Phone,
                    HireDate = t.HireDate,
                    IsActive = t.IsActive,
                    ActiveClassesCount = t.GymClasses.Count(g => g.Schedule > DateTime.Now) // Clases futuras
                })
                .ToListAsync();

            return View(trainers);
        }

        /// <summary>
        /// Muestra el formulario de creación de un nuevo entrenador.
        /// </summary>
        /// <returns>Vista Create con el ViewModel vacío.</returns>
        // GET: Trainers/Create
        public IActionResult Create()
        {
            return View(new TrainerCreateEditViewModel());
        }

        /// <summary>
        /// Crea un nuevo entrenador a partir del modelo recibido.
        /// </summary>
        /// <param name="model">Datos del entrenador.</param>
        /// <returns>Redirección al índice o vista con errores.</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TrainerCreateEditViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Construcción de la entidad Trainer desde el ViewModel
                    var trainer = new Trainer
                    {
                        Name = model.Name,
                        LastName = model.LastName,
                        Specialization = model.Specialization,
                        Email = model.Email,
                        Phone = model.Phone,
                        Bio = model.Bio,
                        HireDate = DateTime.Now, // Fecha de contratación (ahora)
                        IsActive = true          // Nuevo entrenador activo por defecto
                    };

                    _context.Add(trainer);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = $"Entrenador {trainer.FullName} creado exitosamente";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    // Agrega un error de modelo para que se muestre en la vista
                    ModelState.AddModelError("", $"Error al guardar: {ex.Message}");
                }
            }

            // Si hay errores de validación, retornar la vista con el mismo modelo
            return View(model);
        }

        /// <summary>
        /// Muestra el formulario de edición de un entrenador.
        /// </summary>
        /// <param name="id">Identificador del entrenador (string).</param>
        /// <returns>Vista de edición o NotFound si no existe.</returns>
        // GET: Trainers/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }

            var trainer = await _context.Trainers.FindAsync(id);
            if (trainer == null)
            {
                return NotFound();
            }

            // Mapeo a ViewModel de edición (conversión segura de string a int para el Id del VM)
            var model = new TrainerCreateEditViewModel
            {
                Id = int.TryParse(trainer.Id, out var intId) ? intId : 0, // Conversión segura de string a int
                Name = trainer.Name,
                LastName = trainer.LastName,
                Specialization = trainer.Specialization,
                Email = trainer.Email,
                Phone = trainer.Phone,
                Bio = trainer.Bio
            };

            return View(model);
        }

        /// <summary>
        /// Actualiza los datos de un entrenador existente.
        /// </summary>
        /// <param name="id">Identificador del entrenador en la ruta (string).</param>
        /// <param name="model">Modelo con los datos editados.</param>
        /// <returns>Redirección al índice o vista con errores.</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, TrainerCreateEditViewModel model)
        {
            // Comparación del id string con el Id del modelo convertido a string
            if (id != model.Id.ToString())
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var trainer = await _context.Trainers.FindAsync(id);
                    if (trainer == null)
                    {
                        return NotFound();
                    }

                    // Actualización de propiedades permitidas
                    trainer.Name = model.Name;
                    trainer.LastName = model.LastName;
                    trainer.Specialization = model.Specialization;
                    trainer.Email = model.Email;
                    trainer.Phone = model.Phone;
                    trainer.Bio = model.Bio;

                    _context.Update(trainer);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = $"Entrenador {trainer.FullName} actualizado exitosamente";
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    // Verifica si el entrenador aún existe
                    if (!TrainerExists(id))
                    {
                        return NotFound();
                    }
                    // Si existe, relanza la excepción
                    throw;
                }
            }
            // Si el modelo no es válido, regresar la vista con validaciones
            return View(model);
        }

        /// <summary>
        /// Muestra la confirmación de eliminación de un entrenador.
        /// </summary>
        /// <param name="id">Identificador del entrenador.</param>
        /// <returns>Vista de confirmación o NotFound.</returns>
        // GET: Trainers/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }

            var trainer = await _context.Trainers
                .Include(t => t.GymClasses)            // Incluye las clases para validar dependencias
                .FirstOrDefaultAsync(t => t.Id == id);

            if (trainer == null)
            {
                return NotFound();
            }

            // Si tiene clases asignadas, no permitir eliminar
            if (trainer.GymClasses.Any())
            {
                TempData["ErrorMessage"] = $"No se puede eliminar a {trainer.FullName} porque tiene clases asignadas";
                return RedirectToAction(nameof(Index));
            }

            // ViewModel simplificado para mostrar en la vista de confirmación
            var viewModel = new TrainerViewModel
            {
                Id = trainer.Id,
                FullName = trainer.FullName,
                Specialization = trainer.Specialization,
                HireDate = trainer.HireDate,
                IsActive = trainer.IsActive
            };

            return View(viewModel);
        }

        /// <summary>
        /// Elimina definitivamente un entrenador si no tiene clases asignadas.
        /// </summary>
        /// <param name="id">Identificador del entrenador.</param>
        /// <returns>Redirección al índice con mensaje de resultado.</returns>
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var trainer = await _context.Trainers
                .Include(t => t.GymClasses)            // Incluye clases para validar dependencias
                .FirstOrDefaultAsync(t => t.Id == id);

            if (trainer == null)
            {
                return NotFound();
            }

            // Impedir eliminar si tiene clases asignadas
            if (trainer.GymClasses.Any())
            {
                TempData["ErrorMessage"] = $"No se puede eliminar a {trainer.FullName} porque tiene clases asignadas";
                return RedirectToAction(nameof(Index));
            }

            _context.Trainers.Remove(trainer);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"Entrenador {trainer.FullName} eliminado exitosamente";
            return RedirectToAction(nameof(Index));
        }

        /// <summary>
        /// Verifica si existe un entrenador por su Id.
        /// </summary>
        /// <param name="id">Identificador del entrenador.</param>
        /// <returns><c>true</c> si existe; en caso contrario, <c>false</c>.</returns>
        private bool TrainerExists(string id)
        {
            return _context.Trainers.Any(e => e.Id == id);
        }
    }
}
