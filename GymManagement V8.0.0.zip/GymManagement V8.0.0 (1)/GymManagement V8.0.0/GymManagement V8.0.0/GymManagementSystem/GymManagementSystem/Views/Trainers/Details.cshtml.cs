using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GymManagementSystem.Views.Trainers
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
