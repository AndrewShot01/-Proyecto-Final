using GymManagementSystem.Models;           // Modelos usados por las vistas (ErrorViewModel, etc.)
using Microsoft.AspNetCore.Authorization;   // Atributo [Authorize]
using Microsoft.AspNetCore.Mvc;             // Tipos base MVC (Controller, IActionResult)
using System.Diagnostics;                   // Activity para obtener el RequestId

namespace GymManagementSystem.Controllers
{
    /// <summary>
    /// Controlador principal de la aplicaci�n.
    /// Requiere autenticaci�n para acceder a sus acciones por el atributo <see cref="[Authorize]"/>.
    /// </summary>
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger; // Logger para registrar informaci�n/errores

        /// <summary>
        /// Constructor que inyecta el logger espec�fico del HomeController.
        /// </summary>
        /// <param name="logger">Instancia de <see cref="ILogger{HomeController}"/> para registrar eventos.</param>
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Acci�n que retorna la vista principal (Inicio).
        /// </summary>
        /// <returns>Vista Index.</returns>
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Acci�n que retorna la vista de pol�tica de privacidad.
        /// </summary>
        /// <returns>Vista Privacy.</returns>
        public IActionResult Privacy()
        {
            return View();
        }

        /// <summary>
        /// Acci�n para manejar y mostrar errores.
        /// La respuesta no se cachea y se genera un <see cref="ErrorViewModel"/> con el RequestId actual.
        /// </summary>
        /// <returns>Vista Error con el modelo <see cref="ErrorViewModel"/>.</returns>
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)] // Evita cachear la respuesta de error
        public IActionResult Error()
        {
            // Obtiene el identificador de la solicitud actual (Activity) o el TraceIdentifier del HttpContext
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            });
        }
    }
}
