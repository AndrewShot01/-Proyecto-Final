﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GymManagementSystem.Areas.Identity.Data
{
    /// <summary>
    /// Migración: SetDefaultMembershipType
    /// Esta migración se creó con la intención de establecer un valor por defecto
    /// para el tipo de membresía en la base de datos.
    /// 
    /// Actualmente no contiene lógica en los métodos Up ni Down.
    /// </summary>
    public partial class SetDefaultMembershipType : Migration
    {
        /// <summary>
        /// Método Up:
        /// Aquí se definen los cambios que se aplicarán a la base de datos
        /// cuando se ejecute esta migración.
        /// En este caso, está vacío ya que aún no se ha implementado nada.
        /// </summary>
        /// <param name="migrationBuilder">Objeto para construir las operaciones de migración</param>
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Aquí irían las instrucciones para modificar la base de datos
            // Ejemplo: agregar columnas, modificar restricciones, etc.
        }

        /// <summary>
        /// Método Down:
        /// Aquí se definen las operaciones para revertir los cambios realizados
        /// en el método Up, en caso de que sea necesario deshacer la migración.
        /// En este caso, está vacío ya que no se implementaron cambios en Up.
        /// </summary>
        /// <param name="migrationBuilder">Objeto para construir las operaciones de migración</param>
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Aquí irían las instrucciones para revertir los cambios
            // realizados en el método Up.
        }
    }
}
