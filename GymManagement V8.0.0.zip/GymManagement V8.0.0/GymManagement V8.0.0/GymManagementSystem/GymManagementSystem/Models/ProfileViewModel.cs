﻿using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    public class ProfileViewModel
    {
        public string Email { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio")]
        public string Name { get; set; }

        [Required(ErrorMessage = "El apellido es obligatorio")]
        public string LastName { get; set; }
    }
}
