﻿using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    public class TrainerCreateEditViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        [Required(ErrorMessage = "El apellido es obligatorio")]
        [StringLength(100, ErrorMessage = "El apellido no puede exceder 100 caracteres")]
        [Display(Name = "Apellido")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "La especialización es requerida")]
        [StringLength(100, ErrorMessage = "La especialización no puede exceder 100 caracteres")]
        [Display(Name = "Especialización")]
        public string Specialization { get; set; }

        [Required(ErrorMessage = "El email es obligatorio")]
        [EmailAddress(ErrorMessage = "Formato de email inválido")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "El teléfono es obligatorio")]
        [Phone(ErrorMessage = "Formato de teléfono inválido")]
        [Display(Name = "Teléfono")]
        public string Phone { get; set; }

        [Display(Name = "Biografía")]
        [StringLength(1000, ErrorMessage = "La biografía no puede exceder 1000 caracteres")]
        public string Bio { get; set; }
    }
}