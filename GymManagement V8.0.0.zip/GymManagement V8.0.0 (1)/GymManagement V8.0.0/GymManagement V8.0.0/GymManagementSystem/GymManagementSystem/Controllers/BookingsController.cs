﻿using GymManagementSystem.Areas.Identity.Data; // Espacio de nombres con entidades/Identity específicas del sistema
using GymManagementSystem.Models;               // Modelos de dominio (por si se utilizan en el controlador)
using Microsoft.AspNetCore.Authorization;       // Atributos y utilidades de autorización
using Microsoft.AspNetCore.Mvc;                 // Tipos base para controladores y acciones MVC
using Microsoft.EntityFrameworkCore;            // EF Core (incluido por consistencia; útil si se agregan consultas)
using System.Security.Claims;                   // Acceso a claims del usuario autenticado

namespace GymManagementSystem.Controllers
{
    // Restringe el acceso a usuarios autenticados que pertenezcan a cualquiera de estos roles
    [Authorize(Roles = "Admin,Manager,Member")]
    public class BookingsController : Controller
    {
        /// <summary>
        /// Redirige al usuario a la acción "MyBookings" del controlador "GymClasses".
        /// Esta acción actúa como un "alias" o punto de entrada para la vista real de reservas del usuario.
        /// </summary>
        /// <returns>Redirección a GymClasses/MyBookings.</returns>
        public IActionResult MyBookings()
        {
            // Redirecciona a la acción que realmente gestiona/visualiza las reservas del usuario
            return RedirectToAction("MyBookings", "GymClasses");
        }
    }
}
