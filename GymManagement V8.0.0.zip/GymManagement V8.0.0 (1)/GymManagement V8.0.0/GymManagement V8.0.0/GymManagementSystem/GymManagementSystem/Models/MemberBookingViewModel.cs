﻿namespace GymManagementSystem.Models
{
    public class MemberBookingViewModel
    {
        public int Id { get; set; }
        public string GymClassName { get; set; }
        public DateTime Schedule { get; set; }
        public int Duration { get; set; }
        public string InstructorName { get; set; }
        public DateTime BookingDate { get; set; }
        public bool Attended { get; set; }
        public bool CanCancel { get; set; }

        public string FormattedDate => Schedule.ToString("dd/MM/yyyy HH:mm");
        public string DurationText => $"{Duration} minutos";
        public string Status => Attended ? "Asistió" : Schedule > DateTime.Now ? "Pendiente" : "No asistió";
    }
}
