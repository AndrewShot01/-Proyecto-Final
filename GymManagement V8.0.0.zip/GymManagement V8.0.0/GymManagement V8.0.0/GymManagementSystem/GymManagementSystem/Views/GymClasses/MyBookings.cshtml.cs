using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GymManagementSystem.Views.GymClasses
{
    public class MyBookingsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
