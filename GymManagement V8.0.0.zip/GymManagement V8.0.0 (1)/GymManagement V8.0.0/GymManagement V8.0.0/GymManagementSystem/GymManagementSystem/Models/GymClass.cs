﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// Representa una clase de gimnasio (ej. yoga, spinning, etc.).
    /// </summary>
    public class GymClass
    {
        /// <summary>
        /// Identificador único de la clase.
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Nombre de la clase (ejemplo: "Yoga Avanzado").
        /// </summary>
        [Required(ErrorMessage = "El nombre de la clase es requerido")]
        [StringLength(100, ErrorMessage = "El nombre no puede exceder 100 caracteres")]
        [Display(Name = "Nombre de Clase")]
        public string Name { get; set; }

        /// <summary>
        /// Descripción detallada de la clase.
        /// </summary>
        [Required(ErrorMessage = "La descripción es requerida")]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Descripción")]
        public string Description { get; set; }

        /// <summary>
        /// Fecha y hora de inicio de la clase.
        /// </summary>
        [Required(ErrorMessage = "La fecha y hora son requeridas")]
        [Display(Name = "Fecha y Hora")]
        [DataType(DataType.DateTime)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-ddTHH:mm}", ApplyFormatInEditMode = true)]
        public DateTime Schedule { get; set; }

        /// <summary>
        /// Duración en minutos de la clase.
        /// </summary>
        [Required(ErrorMessage = "La duración es requerida")]
        [Range(1, 100, ErrorMessage = "La duración debe ser entre 1-100 minutos")]
        [Display(Name = "Duración (minutos)")]
        public int DurationMinutes { get; set; }

        /// <summary>
        /// Número máximo de participantes permitidos.
        /// </summary>
        [Required(ErrorMessage = "El máximo de participantes es requerido")]
        [Range(1, 50, ErrorMessage = "El máximo de participantes debe ser 1-50")]
        [Display(Name = "Máximo de Participantes")]
        public int MaxParticipants { get; set; }

        /// <summary>
        /// ID del instructor que imparte la clase (relacionado con Trainer).
        /// </summary>
        [Required(ErrorMessage = "Se requiere un instructor")]
        [Display(Name = "Instructor")]
        public string InstructorId { get; set; }  // Se mantiene como string para coincidir con Trainer.Id

        /// <summary>
        /// Relación de navegación con el instructor (Trainer).
        /// </summary>
        [ForeignKey("InstructorId")]
        public virtual Trainer Instructor { get; set; }

        /// <summary>
        /// Relación con los miembros inscritos en la clase.
        /// </summary>
        public virtual ICollection<MemberClass> MemberClasses { get; set; } = new HashSet<MemberClass>();

        // ================== Propiedades calculadas ==================

        /// <summary>
        /// Calcula automáticamente la hora de finalización de la clase.
        /// </summary>
        [NotMapped]
        [Display(Name = "Hora de Finalización")]
        public DateTime EndTime => Schedule.AddMinutes(DurationMinutes);

        /// <summary>
        /// Calcula los cupos disponibles según los inscritos.
        /// </summary>
        [NotMapped]
        [Display(Name = "Disponibilidad")]
        public int AvailableSpots => MaxParticipants - (MemberClasses?.Count ?? 0);

        /// <summary>
        /// Indica el estado de la clase: "Finalizada", "Disponible" o "Llena".
        /// </summary>
        [NotMapped]
        [Display(Name = "Estado")]
        public string Status
        {
            get
            {
                if (Schedule < DateTime.Now) return "Finalizada";
                return AvailableSpots > 0 ? "Disponible" : "Llena";
            }
        }
    }
}
