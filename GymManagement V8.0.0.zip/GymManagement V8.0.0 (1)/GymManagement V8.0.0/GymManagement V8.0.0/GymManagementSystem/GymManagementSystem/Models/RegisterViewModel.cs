﻿using System.ComponentModel.DataAnnotations;

namespace GymManagementSystem.Models
{
    /// <summary>
    /// ViewModel utilizado para el registro de nuevos miembros en el sistema.
    /// Contiene la información básica de acceso y datos personales.
    /// </summary>
    public class RegisterViewModel
    {
        /// <summary>
        /// Correo electrónico del usuario. Se utilizará como identificador principal.
        /// </summary>
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        /// <summary>
        /// Contraseña de la cuenta. Debe cumplir con la longitud mínima y máxima definida.
        /// </summary>
        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} and at max {1} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        /// <summary>
        /// Confirmación de la contraseña. Debe coincidir con el campo Password.
        /// </summary>
        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        /// <summary>
        /// Nombre del miembro que se está registrando.
        /// </summary>
        [Required]
        [Display(Name = "Nombre")]
        public string Name { get; set; }

        /// <summary>
        /// Apellido del miembro que se está registrando.
        /// </summary>
        [Required]
        [Display(Name = "Apellido")]
        public string LastName { get; set; }

        /// <summary>
        /// Tipo de membresía seleccionada por el usuario durante el registro.
        /// </summary>
        [Required]
        [Display(Name = "Tipo de Membresía")]
        public string MembershipType { get; set; }

        /// <summary>
        /// Lista estática de tipos de membresía disponibles en el sistema.
        /// </summary>
        public static readonly List<string> MembershipTypes = new List<string>
        {
            "Basic",
            "Premium",
            "VIP"
        };
    }
}
